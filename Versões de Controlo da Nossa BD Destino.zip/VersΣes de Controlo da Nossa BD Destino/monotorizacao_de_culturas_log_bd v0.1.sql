-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 31-Mar-2019 às 04:42
-- Versão do servidor: 10.1.37-MariaDB
-- versão do PHP: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `monotorizacao_de_culturas_log_bd`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `log`
--

CREATE TABLE `log` (
  `IDLog` int(11) NOT NULL,
  `DataHoraOperacao` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `UtilizadorOperacao` varchar(100) NOT NULL,
  `Operacao` enum('S','I','U','D') NOT NULL,
  `IDVariavelAntigo` int(11) DEFAULT NULL,
  `IDVariavelNovo` int(11) DEFAULT NULL,
  `NomeVariavelAntigo` varchar(100) DEFAULT NULL,
  `NomeVariavelNovo` varchar(100) DEFAULT NULL,
  `IDCulturaAntigo` int(11) DEFAULT NULL,
  `IDCulturaNovo` int(11) DEFAULT NULL,
  `NomeCulturaAntigo` varchar(100) DEFAULT NULL,
  `NomeCulturaNovo` varchar(100) DEFAULT NULL,
  `DescricaoCulturaAntiga` text,
  `DescricaoCulturaNova` text,
  `EmailUtilizadorAntigo` varchar(50) DEFAULT NULL,
  `EmailUtilizadorNovo` varchar(50) DEFAULT NULL,
  `NomeUtilizadorAntigo` varchar(100) DEFAULT NULL,
  `NomeUtilizadorNovo` varchar(100) DEFAULT NULL,
  `PasswordUtilizadorAntigo` varchar(50) DEFAULT NULL,
  `PasswordUtilizadorNovo` varchar(50) DEFAULT NULL,
  `IDVariaveisMedidasAntigo` int(11) DEFAULT NULL,
  `IDVariaveisMedidasNovo` int(11) DEFAULT NULL,
  `LimiteInferiorVariaveisMedidasAntigo` decimal(8,2) DEFAULT NULL,
  `LimiteInferiorVariaveisMedidasNovo` decimal(8,2) DEFAULT NULL,
  `LimiteSuperiorVariaveisMedidasAntigo` decimal(8,2) DEFAULT NULL,
  `LimiteSuperiorVariaveisMedidasNovo` decimal(8,2) DEFAULT NULL,
  `NumeroMedicaoAntigo` int(11) DEFAULT NULL,
  `NumeroMedicaoNovo` int(11) DEFAULT NULL,
  `DataHoraMedicaoMedicoesAntiga` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DataHoraMedicaoMedicoesNova` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ValorMedicaoMedicoesAntigo` decimal(8,2) DEFAULT NULL,
  `ValorMedicaoMedicoesNovo` decimal(8,2) DEFAULT NULL,
  `IDCategoriaProfissionalAntigo` int(11) DEFAULT NULL,
  `IDCategoriaProfissionalNovo` int(11) DEFAULT NULL,
  `NomeCategoriaProfissionalAntigo` varchar(100) DEFAULT NULL,
  `NomeCategoriaProfissionalNovo` varchar(100) DEFAULT NULL,
  `IDTipoCulturaAntigo` int(11) DEFAULT NULL,
  `IDTipoCulturaNovo` int(11) DEFAULT NULL,
  `NomeTipoCulturaAntigo` varchar(100) DEFAULT NULL,
  `NomeTipoCulturaNovo` varchar(100) DEFAULT NULL,
  `IDMedicaoLuminosidadeTemperaturaAntigo` int(11) DEFAULT NULL,
  `IDMedicaoLuminosidadeTemperaturaNovo` int(11) DEFAULT NULL,
  `DataHoraMedicaoMedicoesLuminosidadeTemperaturaAntiga` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DataHoraMedicaoMedicoesLuminosidadeTemperaturaNova` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ValorMedicaoLuminosidadeAntigo` decimal(8,2) DEFAULT NULL,
  `ValorMedicaoLuminosidadeNovo` decimal(8,2) DEFAULT NULL,
  `ValorMedicaoTemperaturaAntigo` decimal(8,2) DEFAULT NULL,
  `ValorMedicaoTemperaturaNovo` decimal(8,2) DEFAULT NULL,
  `IDSistemaAntigo` int(11) DEFAULT NULL,
  `IDSistemaNovo` int(11) DEFAULT NULL,
  `LimiteInferiorTemperaturaSistemaAntigo` decimal(8,2) DEFAULT NULL,
  `LimiteInferiorTemperaturaSistemaNovo` decimal(8,2) DEFAULT NULL,
  `LimiteInferiorLuminosidadeSistemaAntigo` decimal(8,2) DEFAULT NULL,
  `LimiteInferiorLuminosidadeSistemaNovo` decimal(8,2) DEFAULT NULL,
  `LimiteSuperiorTemperaturaSistemaAntigo` decimal(8,2) DEFAULT NULL,
  `LimiteSuperiorTemperaturaSistemaNovo` decimal(8,2) DEFAULT NULL,
  `LimiteSuperiorLuminosidadeSistemaAntigo` decimal(8,2) DEFAULT NULL,
  `LimiteSuperiorLuminosidadeSistemaNovo` decimal(8,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `log`
--
ALTER TABLE `log`
  ADD PRIMARY KEY (`IDLog`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `log`
--
ALTER TABLE `log`
  MODIFY `IDLog` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
