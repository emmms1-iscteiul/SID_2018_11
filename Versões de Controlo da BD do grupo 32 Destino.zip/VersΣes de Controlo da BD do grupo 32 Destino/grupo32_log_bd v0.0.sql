-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 26-Mar-2019 às 22:15
-- Versão do servidor: 10.1.37-MariaDB
-- versão do PHP: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `grupo32_log_bd`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `logtemp_cultura`
--

CREATE TABLE `logtemp_cultura` (
  `IdLog` int(11) NOT NULL,
  `Utilizador` varchar(100) NOT NULL,
  `DataHoraLog` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Operação` enum('S','I','U','D') NOT NULL,
  `IdCultura` int(11) NOT NULL,
  `NomeCultura` varchar(100) DEFAULT NULL,
  `DescriçãoCultura` text,
  `TipoCultura` int(11) NOT NULL,
  `IdUtilizador` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `logtemp_medicao`
--

CREATE TABLE `logtemp_medicao` (
  `IdLog` int(11) NOT NULL,
  `Utilizador` varchar(100) NOT NULL,
  `DataHoraLog` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Operação` enum('S','I','U','D') NOT NULL,
  `IdMedição` int(11) NOT NULL,
  `DataHoraMedição` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `ValorMedição` decimal(8,2) DEFAULT NULL,
  `IdVariávelMedida` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `logtemp_medicao_luminosidade`
--

CREATE TABLE `logtemp_medicao_luminosidade` (
  `IdLog` int(11) NOT NULL,
  `Utilizador` varchar(100) NOT NULL,
  `DataHoraLog` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Operação` enum('S','I','U','D') NOT NULL,
  `DataHoraMedição` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `ValorMediçãoLuminosidade` decimal(8,2) DEFAULT NULL,
  `IdMedição` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `logtemp_medicao_temperatura`
--

CREATE TABLE `logtemp_medicao_temperatura` (
  `IdLog` int(11) NOT NULL,
  `Utilizador` varchar(100) NOT NULL,
  `DataHoraLog` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Operação` enum('S','I','U','D') NOT NULL,
  `IdMedição` int(11) NOT NULL,
  `DataHoraMediçãoTemperatura` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ValorMediçãoTemperatura` decimal(8,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `logtemp_sistema`
--

CREATE TABLE `logtemp_sistema` (
  `IdLog` int(11) NOT NULL,
  `Utilizador` varchar(100) NOT NULL,
  `DataHoraLog` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Operação` enum('S','I','U','D') NOT NULL,
  `LimiteSuperiorTemperatura` decimal(8,2) DEFAULT NULL,
  `LimiteInferiorTemperatura` decimal(8,2) DEFAULT NULL,
  `LimiteSuperiorLuminosidade` decimal(8,2) DEFAULT NULL,
  `LimiteInferiorLuminosidade` decimal(8,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `logtemp_tipo_cultura`
--

CREATE TABLE `logtemp_tipo_cultura` (
  `IdLog` int(11) NOT NULL,
  `Utilizador` varchar(100) NOT NULL,
  `DataHoraLog` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Operação` enum('S','I','U','D') NOT NULL,
  `IdTipoCultura` int(11) NOT NULL,
  `NomeTipoCultura` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `logtemp_utilizador`
--

CREATE TABLE `logtemp_utilizador` (
  `IdLog` int(11) NOT NULL,
  `Utilizador` varchar(100) NOT NULL,
  `DataHoraLog` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Operação` enum('S','I','U','D') NOT NULL,
  `Password` varchar(50) NOT NULL,
  `IdUtilizador` int(11) NOT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `NomeUtilizador` varchar(100) DEFAULT NULL,
  `CategoriaProfissional` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `logtemp_variavel`
--

CREATE TABLE `logtemp_variavel` (
  `IdLog` int(11) NOT NULL,
  `Utilizador` varchar(100) NOT NULL,
  `DataHoraLog` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Operação` enum('S','I','U','D') NOT NULL,
  `IdVariável` int(11) NOT NULL,
  `NomeVariável` varchar(100) DEFAULT NULL,
  `IdCultura` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `logtemp_variavel_medida`
--

CREATE TABLE `logtemp_variavel_medida` (
  `IdLog` int(11) NOT NULL,
  `Utilizador` varchar(100) NOT NULL,
  `DataHoraLog` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Operação` enum('S','I','U','D') NOT NULL,
  `LimiteInferior` decimal(8,2) DEFAULT NULL,
  `LimiteSuperior` decimal(8,2) DEFAULT NULL,
  `IdCultura` int(11) NOT NULL,
  `IdVariável` int(11) NOT NULL,
  `IdVariávelMedida` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `log_cultura`
--

CREATE TABLE `log_cultura` (
  `IdLog` int(11) NOT NULL,
  `Utilizador` varchar(100) NOT NULL,
  `DataHoraLog` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Operação` enum('S','I','U','D') NOT NULL,
  `IdCultura` int(11) NOT NULL,
  `NomeCultura` varchar(100) DEFAULT NULL,
  `DescriçãoCultura` text,
  `TipoCultura` int(11) NOT NULL,
  `IdUtilizador` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `log_medicao`
--

CREATE TABLE `log_medicao` (
  `IdLog` int(11) NOT NULL,
  `Utilizador` varchar(100) NOT NULL,
  `DataHoraLog` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Operação` enum('S','I','U','D') NOT NULL,
  `IdMedição` int(11) NOT NULL,
  `DataHoraMedição` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `ValorMedição` decimal(8,2) DEFAULT NULL,
  `IdVariávelMedida` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `log_medicao_luminosidade`
--

CREATE TABLE `log_medicao_luminosidade` (
  `IdLog` int(11) NOT NULL,
  `Utilizador` varchar(100) NOT NULL,
  `DataHoraLog` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Operação` enum('S','I','U','D') NOT NULL,
  `DataHoraMedição` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `ValorMediçãoLuminosidade` decimal(8,2) DEFAULT NULL,
  `IdMedição` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `log_medicao_temperatura`
--

CREATE TABLE `log_medicao_temperatura` (
  `IdLog` int(11) NOT NULL,
  `Utilizador` varchar(100) NOT NULL,
  `DataHoraLog` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Operação` enum('S','I','U','D') NOT NULL,
  `IdMedição` int(11) NOT NULL,
  `DataHoraMediçãoTemperatura` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ValorMediçãoTemperatura` decimal(8,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `log_sistema`
--

CREATE TABLE `log_sistema` (
  `IdLog` int(11) NOT NULL,
  `Utilizador` varchar(100) NOT NULL,
  `DataHoraLog` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Operação` enum('S','I','U','D') NOT NULL,
  `LimiteSuperiorTemperatura` decimal(8,2) DEFAULT NULL,
  `LimiteInferiorTemperatura` decimal(8,2) DEFAULT NULL,
  `LimiteSuperiorLuminosidade` decimal(8,2) DEFAULT NULL,
  `LimiteInferiorLuminosidade` decimal(8,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `log_tipo_cultura`
--

CREATE TABLE `log_tipo_cultura` (
  `IdLog` int(11) NOT NULL,
  `Utilizador` varchar(100) NOT NULL,
  `DataHoraLog` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Operação` enum('S','I','U','D') NOT NULL,
  `IdTipoCultura` int(11) NOT NULL,
  `NomeTipoCultura` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `log_utilizador`
--

CREATE TABLE `log_utilizador` (
  `IdLog` int(11) NOT NULL,
  `Utilizador` varchar(100) NOT NULL,
  `DataHoraLog` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Operação` enum('S','I','U','D') NOT NULL,
  `Password` varchar(50) NOT NULL,
  `IdUtilizador` int(11) NOT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `NomeUtilizador` varchar(100) DEFAULT NULL,
  `CategoriaProfissional` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `log_variavel`
--

CREATE TABLE `log_variavel` (
  `IdLog` int(11) NOT NULL,
  `Utilizador` varchar(100) NOT NULL,
  `DataHoraLog` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Operação` enum('S','I','U','D') NOT NULL,
  `IdVariável` int(11) NOT NULL,
  `NomeVariável` varchar(100) DEFAULT NULL,
  `IdCultura` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `log_variavel_medida`
--

CREATE TABLE `log_variavel_medida` (
  `IdLog` int(11) NOT NULL,
  `Utilizador` varchar(100) NOT NULL,
  `DataHoraLog` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Operação` enum('S','I','U','D') NOT NULL,
  `LimiteInferior` decimal(8,2) DEFAULT NULL,
  `LimiteSuperior` decimal(8,2) DEFAULT NULL,
  `IdCultura` int(11) NOT NULL,
  `IdVariável` int(11) NOT NULL,
  `IdVariávelMedida` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
