DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `alterarCulturaNome`(IN `nomeC` VARCHAR(100), IN `idC` INT(11))
BEGIN

	DELETE FROM variavel_medida WHERE IdCultura=idC;

	UPDATE cultura SET NomeCultura=nomeC WHERE IdCultura=idC;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `alterarCulturaDescricao`(IN `descC` VARCHAR(100), IN `idC` INT(11))
BEGIN

	UPDATE cultura SET DescricaoCultura=descC WHERE IdCultura=idC;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `alterarUtilizadorNome`(IN `nomeU` VARCHAR(100), IN `idU` INT(11))
BEGIN

	DELETE FROM cultura WHERE IdUtilizador=idU;
    
    SELECT NomeUtilizador INTO @nomeUA FROM utilizador WHERE IdUtilizador=idU;
    
    SET @query1 = CONCAT('RENAME USER "',@nomeUA,'"@"localhost" TO "',nomeU,'"@"localhost"');

    PREPARE stmt FROM @query1;
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;

	UPDATE utilizador SET NomeUtilizador=nomeU WHERE IdUtilizador=idU;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `alterarUtilizadorEmail`(IN `mailU` VARCHAR(100), IN `idU` VARCHAR(100))
BEGIN

	UPDATE utilizador SET Email=mailU WHERE IdUtilizador=idU;
    
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `alterarCulturaUtilizador`(IN `nomeU` VARCHAR(100), IN `idC` INT(11))
BEGIN

	SELECT IdUtilizador INTO @idU FROM utilizador WHERE NomeUtilizador=nomeU;

	UPDATE cultura SET IdUtilizador=@idU WHERE IdCultura=idC;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `alterarUtilizadorPass`(IN `pass` VARCHAR(50), IN `idU` INT(11))
BEGIN

	UPDATE utilizador SET Passwor=pass WHERE IdUtilizador=idU;
    
    SELECT NomeUtilizador INTO @nomeU FROM utilizador WHERE IdUtilizador=idU;
    
    SET @query1 := CONCAT('SET PASSWORD FOR "', @nomeU, '"@"localhost" = PASSWORD("',pass,'") ');
    
    PREPARE stmt FROM @query1;
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
    
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `alterarVariavelMedidaAlertaLimiteInferior`(IN `regulLimiteI` DECIMAL, IN `idVM` INT(11))
BEGIN

	UPDATE variavel_medida SET LimiteRegularidadeAlertasInferior=regulLimiteI WHERE IdVariavelMedida=idVM;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `alterarVariavelMedidaAlertaLimiteSuperior`(IN `regulLimiteS` DECIMAL, IN `idVM` INT(11))
BEGIN

	UPDATE variavel_medida SET LimiteRegularidadeAlertasSuperior=regulLimiteS WHERE IdVariavelMedida=idVM;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `alterarVariavelMedidaCultura`(IN `nomeC` VARCHAR(100), IN `idVM` INT)
BEGIN

	SELECT IdCultura INTO @idC FROM cultura WHERE NomeCultura=nomeC;

	DELETE FROM medicao WHERE IdCultura=@idC;

	UPDATE variavel_medida SET IdCultura=@idC WHERE IdVariavelMedida=idVM;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `alterarVariavelMedidaLimiteInferior`(IN `limiteI` DECIMAL, IN `idVM` INT(11))
BEGIN

	UPDATE variavel_medida SET LimiteInferior=limiteI WHERE IdVariavelMedida=idVM;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `alterarVariavelMedidaLimiteSuperior`(IN `limiteS` DECIMAL, IN `idVM` INT(11))
BEGIN

	UPDATE variavel_medida SET LimiteSuperior=limiteS WHERE IdVariavelMedida=idVM;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `alterarVariavelMedidaVariavel`(IN `nomeV` VARCHAR(100), IN `idVM` INT(11))
BEGIN

	SELECT IdVariavel INTO @idV FROM variavel WHERE NomeVariavel=nomeV;
    
    SELECT IdCultura INTO @idC from variavel_medida WHERE IdVariavel=@idV AND IdVariavelMedida=idVM;
    
    DELETE FROM medicao WHERE IdVariavel=@idV AND IdCultura=@idC;

	UPDATE variavel_medida SET IdVariavel=@idV WHERE IdVariavelMedida=idVM;
    
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `alterarVariavelNome`(IN `nomeV` VARCHAR(100), IN `idV` INT(11))
BEGIN

	UPDATE variavel SET NomeVariavel=nomeV WHERE IdVariavel=idV;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `apagarCultura`(IN `idC` INT(11))
BEGIN
    
    DELETE FROM cultura WHERE IdCultura=idC;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `apagarUtilizador`(IN `idU` INT(11))
BEGIN

	SELECT NomeUtilizador INTO @nomeU FROM utilizador WHERE IdUtilizador=idU;

	DELETE FROM utilizador WHERE IdUtilizador=idU;
    
    SET @query1 := CONCAT('DROP USER "',@nomeU, '"@"localhost" ');
    
     PREPARE stmt FROM @query1;
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
   
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `apagarVariavel`(IN `idV` INT(11))
BEGIN

	DELETE FROM variavel WHERE IdVariavel=idV;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `consultarCulturas`()
BEGIN

	SELECT IdCultura, NomeCultura, DescricaoCultura, NomeUtilizador FROM cultura, utilizador WHERE cultura.IdUtilizador=utilizador.IdUtilizador;
    
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `consultarMedicoes`()
BEGIN

	SELECT IdMedicao, DataHoraMedicao, ValorMedicao, NomeCultura, NomeVariavel FROM variavel, medicao, cultura WHERE cultura.IdCultura = medicao.IdCultura AND medicao.IdVariavel = variavel.IdVariavel;
    
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `consultarUtilizadores`()
BEGIN

	SELECT IdUtilizador, Email, NomeUtilizador, Passwor FROM utilizador;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `consultarVariaveis`()
BEGIN

	SELECT * FROM variavel;
    
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `consultarVariaveisInvestigador`()
BEGIN

	SELECT IdVariavel, NomeVariavel FROM variavel;
    
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `consultarVariaveisMedidas`()
BEGIN

	SELECT IdVariavelMedida, LimiteInferior, LimiteSuperior, LimiteRegularidadeAlertasInferior, LimiteRegularidadeAlertasSuperior, NomeCultura, NomeVariavel FROM variavel, variavel_medida, cultura WHERE cultura.IdCultura = variavel_medida.IdCultura AND variavel_medida.IdVariavel = variavel.IdVariavel;
    
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `filtrarAlertasCultura`()
BEGIN

	SET @nome := USER();
    SET @nomeutilizador := SUBSTRING_INDEX(@nome, '@', 1);
    
    SELECT IdUtilizador INTO @idU FROM utilizador WHERE NomeUtilizador=@nomeutilizador;
    
    SELECT DataHoraAlerta,NomeVariavelAlerta, LimiteSuperiorAlerta, LimiteInferiorAlerta, ValorMedicaoAlerta, Descricao FROM alerta_cultura, variavel_medida, variavel, cultura WHERE alerta_cultura.NomeVariavelAlerta=variavel.NomeVariavel AND variavel_medida.IdVariavel=variavel.IdVariavel AND variavel_medida.IdCultura=cultura.IdCultura AND cultura.IdUtilizador=@idU;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `filtrarCulturaTudo`()
BEGIN

	SET @nome := USER();
    SET @nomeUtilizador := SUBSTRING_INDEX(@nome, '@', 1);

	SELECT IdUtilizador INTO @idU FROM utilizador WHERE NomeUtilizador=@nomeUtilizador;

        SELECT IdCultura, NomeCultura, DescricaoCultura FROM cultura WHERE cultura.IdUtilizador=@idU;
        
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `filtrarMedicaoTudo`()
BEGIN

	SET @nome := USER();
    SET @nomeutilizador := SUBSTRING_INDEX(@nome,'@',1);

	SELECT IDUTilizador INTO @idU FROM utilizador WHERE NomeUtilizador=@nomeutilizador;

        SELECT NomeCultura, NomeVariavel, DataHoraMedicao, ValorMedicao, LimiteInferior, LimiteSuperior FROM medicao, cultura, variavel_medida, variavel WHERE variavel_medida.IDVariavel=variavel.IDVariavel AND medicao.IDVariavel=variavel.IDVariavel AND medicao.IDCultura=cultura.IDCultura AND variavel_medida.IDCultura=cultura.IDCultura AND cultura.IdUtilizador=@idU;
        
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `filtrarVariaveisMedidasTudo`()
BEGIN

	SET @nome := USER();
    SET @nomeutilizador := SUBSTRING_INDEX(@nome,'@',1);

	SELECT IdUTilizador INTO @idU FROM utilizador WHERE NomeUtilizador=@nomeutilizador;

        SELECT IdVariavelMedida,LimiteInferior, LimiteSuperior, LimiteRegularidadeAlertasInferior, LimiteRegularidadeAlertasSuperior, NomeCultura, NomeVariavel FROM variavel_medida, cultura, variavel WHERE cultura.IdCultura=variavel_medida.IdCultura AND variavel.IdVariavel=variavel_medida.IdVariavel AND cultura.IdUtilizador=@idU;
        
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `inserirAdmin`(IN `mailU` VARCHAR(100), IN `nomeU` VARCHAR(100), IN `pass` VARCHAR(50))
BEGIN

    INSERT INTO utilizador(Email, NomeUtilizador, TipoUtilizador, Passwor) VALUES (mailU, nomeU, 1, pass);
    
    SET @query1 = CONCAT('CREATE USER "',nomeU,'"@"localhost" IDENTIFIED BY "',pass,'" ');

    PREPARE stmt FROM @query1;
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;

   SET @priv := CONCAT('GRANT ALL PRIVILEGES ON  *.* TO "',nomeU, '"@"localhost"');

    PREPARE stmt FROM @priv;
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
    
    FLUSH PRIVILEGES;
    
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `inserirCultura`(IN `nomeC` VARCHAR(100), IN `descrC` TEXT)
BEGIN

    SET @nome := USER();
    SET @nomeutilizador := SUBSTRING_INDEX(@nome,'@',1);

    SELECT IDUtilizador INTO @idU FROM utilizador WHERE NomeUtilizador=@nomeutilizador;

    INSERT INTO cultura(NomeCultura, DescricaoCultura, TipoCultura, IDUtilizador) VALUES (nomeC, descrC, 1, @idU);

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `inserirInvestigador`(IN `mailU` VARCHAR(100), IN `nomeU` VARCHAR(100), IN `pass` VARCHAR(50))
BEGIN
	   
    INSERT INTO utilizador(Email, NomeUtilizador, TipoUtilizador, Passwor) VALUES (mailU, nomeU, 2, pass);
    
    SET @query1 = CONCAT('CREATE USER "',nomeU,'"@"localhost" IDENTIFIED BY "',pass,'" ');

    PREPARE stmt FROM @query1;
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
    
    SET @query3 := CONCAT('GRANT EXECUTE ON PROCEDURE monotorizacao_de_culturas.filtrarMedicaoTudo TO "', nomeU, '"@"localhost"');

    PREPARE stmt FROM @query3;
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
    
    FLUSH PRIVILEGES;
    
     SET @query5 := CONCAT('GRANT EXECUTE ON PROCEDURE monotorizacao_de_culturas.filtrarCulturaTudo TO "', nomeU, '"@"localhost"');

    PREPARE stmt FROM @query5;
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;

	FLUSH PRIVILEGES;
    
    SET @query6 := CONCAT('GRANT EXECUTE ON PROCEDURE monotorizacao_de_culturas.inserirCultura TO "', nomeU, '"@"localhost"');

    PREPARE stmt FROM @query6;
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
    
    FLUSH PRIVILEGES;
    
    SET @query7 := CONCAT('GRANT EXECUTE ON PROCEDURE monotorizacao_de_culturas.apagarCultura TO "', nomeU, '"@"localhost"');

    PREPARE stmt FROM @query7;
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
    
    FLUSH PRIVILEGES;
    
    SET @query8 := CONCAT('GRANT EXECUTE ON PROCEDURE monotorizacao_de_culturas.alterarCulturaNome TO "', nomeU, '"@"localhost"');

    PREPARE stmt FROM @query8;
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
    
    FLUSH PRIVILEGES;
    
    SET @query9 := CONCAT('GRANT EXECUTE ON PROCEDURE monotorizacao_de_culturas.alterarCulturaDescricao TO "', nomeU, '"@"localhost"');

    PREPARE stmt FROM @query9;
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
    
    FLUSH PRIVILEGES;
    
    SET @query10 := CONCAT('GRANT EXECUTE ON PROCEDURE monotorizacao_de_culturas.alterarCulturaUtilizador TO "',nomeU, '"@"localhost"');

    PREPARE stmt FROM @query10;
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
    
    FLUSH PRIVILEGES;
    
    SET @query11 := CONCAT('GRANT EXECUTE ON PROCEDURE monotorizacao_de_culturas.inserirMedicao TO "', nomeU, '"@"localhost"');

    PREPARE stmt FROM @query11;
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
    
    FLUSH PRIVILEGES;
    
    SET @query12 := CONCAT('GRANT EXECUTE ON PROCEDURE monotorizacao_de_culturas.inserirVariavelMedida TO "', nomeU, '"@"localhost"');

    PREPARE stmt FROM @query12;
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
    
    FLUSH PRIVILEGES;
    
    SET @query13 := CONCAT('GRANT EXECUTE ON PROCEDURE monotorizacao_de_culturas.alterarVariavelMedidaLimiteSuperior TO "', nomeU, '"@"localhost"');

    PREPARE stmt FROM @query13;
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
    
    FLUSH PRIVILEGES;
    
    SET @query14 := CONCAT('GRANT EXECUTE ON PROCEDURE monotorizacao_de_culturas.alterarVariavelMedidaLimiteInferior TO "', nomeU, '"@"localhost"');

    PREPARE stmt FROM @query14;
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
    
    FLUSH PRIVILEGES;
    
    SET @query15 := CONCAT('GRANT EXECUTE ON PROCEDURE monotorizacao_de_culturas.alterarVariavelMedidaAlertaLimiteInferior TO "', nomeU, '"@"localhost"');

    PREPARE stmt FROM @query15;
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
    
    FLUSH PRIVILEGES;
    
    SET @query16 := CONCAT('GRANT EXECUTE ON PROCEDURE monotorizacao_de_culturas.alterarVariavelMedidaAlertaLimiteSuperior TO "', nomeU, '"@"localhost"');

    PREPARE stmt FROM @query16;
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
    
    FLUSH PRIVILEGES;
    
    SET @query17 := CONCAT('GRANT EXECUTE ON PROCEDURE monotorizacao_de_culturas.alterarVariavelMedidaVariavel TO "', nomeU, '"@"localhost"');

    PREPARE stmt FROM @query17;
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
    
    FLUSH PRIVILEGES;
    
    SET @query18 := CONCAT('GRANT EXECUTE ON PROCEDURE monotorizacao_de_culturas.alterarVariavelMedidaCultura TO "', nomeU, '"@"localhost"');

    PREPARE stmt FROM @query18;
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
    
    FLUSH PRIVILEGES;
    
    SET @query19 := CONCAT('GRANT EXECUTE ON PROCEDURE monotorizacao_de_culturas.consultarVariaveisInvestigador TO "', nomeU, '"@"localhost"');

	PREPARE stmt FROM @query19;
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
    
    FLUSH PRIVILEGES;
    
    SET @query20 := CONCAT('GRANT EXECUTE ON PROCEDURE monotorizacao_de_culturas.filtrarVariaveisMedidasTudo TO "', nomeU, '"@"localhost"');

	PREPARE stmt FROM @query20;
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
    
    FLUSH PRIVILEGES;
    
     SET @query21 := CONCAT('GRANT EXECUTE ON PROCEDURE monotorizacao_de_culturas.filtrarAlertasCultura TO "', nomeU, '"@"localhost"');

	PREPARE stmt FROM @query21;
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
    
    FLUSH PRIVILEGES;
    
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `inserirVariavel`(IN `nomeV` VARCHAR(100))
BEGIN

	INSERT INTO variavel(NomeVariavel) VALUES (nomeV);

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `inserirVariavelMedida`(IN `limiteI` DECIMAL, IN `limiteS` DECIMAL, IN `nomeV` VARCHAR(100), IN `nomeC` VARCHAR(100), IN `regulLimiteI` DECIMAL, IN `regulLimiteS` DECIMAL)
BEGIN

	SET @nome := USER();
    SET @nomeutilizador := SUBSTRING_INDEX(@nome, '@', 1);
    
    SELECT IdUtilizador INTO @idU FROM utilizador WHERE NomeUtilizador=@nomeutilizador;
    
    SELECT IdCultura INTO @idC FROM cultura WHERE cultura.IdUtilizador=@idU AND NomeCultura=nomeC;
    
    SELECT IdVariavel INTO @idV FROM variavel WHERE NomeVariavel=nomeV;
    
    INSERT INTO variavel_medida(LimiteInferior, LimiteSuperior, LimiteRegularidadeAlertasInferior, LimiteRegularidadeAlertasSuperior, IdCultura, IdVariavel) VALUES (limiteI, limiteS, regulLimiteI, regulLimiteS, @idC, @idV);

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `obterPassword`(IN `nomeU` VARCHAR(100))
BEGIN

	SELECT Passwor FROM utilizador WHERE NomeUtilizador=nomeU;
    
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `obterTipoUtilizador`(IN `nomeU` VARCHAR(100))
BEGIN

	SELECT TipoUtilizador INTO @idT FROM utilizador WHERE NomeUtilizador=nomeU;

	SELECT TipoUtilizador FROM tipo_utilizador WHERE IDTipoUtilizador=@idT;

END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `inserirMedicao`(IN `valorM` DECIMAL, IN `nomeC` VARCHAR(100), IN `nomeV` VARCHAR(100))
BEGIN

	SET @nome := USER();
    SET @nomeutilizador := SUBSTRING_INDEX(@nome, '@', 1);
    
    SELECT IdUtilizador INTO @idU FROM utilizador WHERE NomeUtilizador=@nomeU;
    
   SELECT variavel_medida.IdCultura INTO @idC FROM cultura, variavel_medida WHERE cultura.IdUtilizador=@idU AND cultura.NomeCultura=nomeC AND variavel_medida.IdCultura=cultura.IdCultura;
    
    SELECT variavel_medida.IdVariavel INTO @idV FROM variavel, variavel_medida WHERE variavel.NomeVariavel=nomeV AND variavel_medida.IdVariavel=variavel.IdVariavel AND variavel_medida.IdCultura=@idC;
    
    INSERT INTO medicao(ValorMedicao, IdCultura, IdVariavel) VALUES (valorM, @idC, @idV);
	

END$$
DELIMITER ;
