-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 26-Mar-2019 às 14:09
-- Versão do servidor: 10.1.37-MariaDB
-- versão do PHP: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `monotorizacao_de_culturas`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `categoria_profissional`
--

CREATE TABLE `categoria_profissional` (
  `IDCategoriaProfissional` int(11) NOT NULL,
  `NomeCategoriaProfissional` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `cultura`
--

CREATE TABLE `cultura` (
  `IDCultura` int(11) NOT NULL,
  `NomeCultura` varchar(100) NOT NULL,
  `DescricaoCultura` text,
  `EmailUtilizador` varchar(50) NOT NULL,
  `IDTipoCultura` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `log`
--

CREATE TABLE `log` (
  `IDLog` int(11) NOT NULL,
  `DataHoraOperacao` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `UtilizadorOperacao` varchar(100) NOT NULL,
  `Operacao` enum('S','I','U','D') NOT NULL,
  `IDVariavelAntigo` int(11) DEFAULT NULL,
  `IDVariavelNovo` int(11) DEFAULT NULL,
  `NomeVariavelAntigo` varchar(100) DEFAULT NULL,
  `NomeVariavelNovo` varchar(100) DEFAULT NULL,
  `IDCulturaAntigo` int(11) DEFAULT NULL,
  `IDCulturaNovo` int(11) DEFAULT NULL,
  `NomeCulturaAntigo` varchar(100) DEFAULT NULL,
  `NomeCulturaNovo` varchar(100) DEFAULT NULL,
  `DescicaoCulturaAntiga` text,
  `DescicaoCulturaNova` text,
  `EmailUtilizadorAntigo` varchar(50) DEFAULT NULL,
  `EmailUtilizadorNovo` varchar(50) DEFAULT NULL,
  `NomeUtilizadorAntigo` varchar(100) DEFAULT NULL,
  `NomeUtilizadorNovo` varchar(100) DEFAULT NULL,
  `PasswordUtilizadorAntigo` varchar(50) DEFAULT NULL,
  `PasswordUtilizadorNovo` varchar(50) DEFAULT NULL,
  `IDVariaveisMedidasNovo` int(11) DEFAULT NULL,
  `IDVariaveisMedidasAntigo` int(11) DEFAULT NULL,
  `LimiteInferiorVariaveisMedidasAntigo` decimal(8,2) DEFAULT NULL,
  `LimiteInferiorVariaveisMedidasNovo` decimal(8,2) DEFAULT NULL,
  `LimiteSuperiorVariaveisMedidasAntigo` decimal(8,2) DEFAULT NULL,
  `LimiteSuperiorVariaveisMedidasNovo` decimal(8,2) DEFAULT NULL,
  `NumeroMedicaoAntigo` int(11) DEFAULT NULL,
  `NumeroMedicaoNovo` int(11) DEFAULT NULL,
  `DataHoraMedicaoMedicoesAntiga` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DataHoraMedicaoMedicoesNova` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ValorMedicaoMedicoesAntigo` decimal(8,2) DEFAULT NULL,
  `ValorMedicaoMedicoesNovo` decimal(8,2) DEFAULT NULL,
  `IDCategoriaProfissionalAntigo` int(11) DEFAULT NULL,
  `IDCategoriaProfissionalNovo` int(11) DEFAULT NULL,
  `NomeCategoriaProfissionalAntigo` varchar(100) DEFAULT NULL,
  `NomeCategoriaProfissionalNovo` varchar(100) DEFAULT NULL,
  `IDTipoCulturaAntigo` int(11) DEFAULT NULL,
  `IDTipoCulturaNovo` int(11) DEFAULT NULL,
  `NomeTipoCulturaAntigo` varchar(100) DEFAULT NULL,
  `NomeTipoCulturaNovo` varchar(100) DEFAULT NULL,
  `IDMedicaoLuminosidadeTemperaturaAntigo` int(11) DEFAULT NULL,
  `IDMedicaoLuminosidadeTemperaturaNovo` int(11) DEFAULT NULL,
  `DataHoraMedicaoMedicoesLuminosidadeTemperaturaAntiga` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DataHoraMedicaoMedicoesLuminosidadeTemperaturaNova` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ValorMedicaoLuminosidadeAntigo` decimal(8,2) DEFAULT NULL,
  `ValorMedicaoLuminosidadeNovo` decimal(8,2) DEFAULT NULL,
  `ValorMedicaoTemperaturaAntigo` decimal(8,2) DEFAULT NULL,
  `ValorMedicaoTemperaturaNovo` decimal(8,2) DEFAULT NULL,
  `IDSistemaAntigo` int(11) DEFAULT NULL,
  `IDSistemaNovo` int(11) DEFAULT NULL,
  `LimiteInferiorTemperaturaSistemaAntigo` decimal(8,2) DEFAULT NULL,
  `LimiteInferiorTemperaturaSistemaNovo` decimal(8,2) DEFAULT NULL,
  `LimiteInferiorLuminosidadeSistemaAntigo` decimal(8,2) DEFAULT NULL,
  `LimiteInferiorLuminosidadeSistemaNovo` decimal(8,2) DEFAULT NULL,
  `LimiteSuperiorTemperaturaSistemaAntigo` decimal(8,2) DEFAULT NULL,
  `LimiteSuperiorTemperaturaSistemaNovo` decimal(8,2) DEFAULT NULL,
  `LimiteSuperiorLuminosidadeSistemaAntigo` decimal(8,2) DEFAULT NULL,
  `LimiteSuperiorLuminosidadeSistemaNovo` decimal(8,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `medicoes`
--

CREATE TABLE `medicoes` (
  `NumeroMedicao` int(11) NOT NULL,
  `IDVariaveisMedidas` int(11) NOT NULL,
  `DataHoraMedicaoMedicoes` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ValorMedicaoMedicoes` decimal(8,2) NOT NULL,
  `IDCultura` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `medicoes_luminosidade_e_temperatura`
--

CREATE TABLE `medicoes_luminosidade_e_temperatura` (
  `IDMedicaoLuminosidadeTemperatura` int(11) NOT NULL,
  `DataHoraMedicaoLuminosidadeTemperatura` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ValorMedicaoTemperatura` decimal(8,2) NOT NULL,
  `ValorMedicaoLuminosidade` decimal(8,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `sistema`
--

CREATE TABLE `sistema` (
  `IdSistema` int(11) NOT NULL,
  `LimiteInferiorTemperatura` decimal(8,2) NOT NULL,
  `LimiteSuperiorTemperatura` decimal(8,2) NOT NULL,
  `LimiteSuperiorLuz` decimal(8,2) NOT NULL,
  `LimiteInferiorLuz` decimal(8,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `sistema`
--

INSERT INTO `sistema` (`IdSistema`, `LimiteInferiorTemperatura`, `LimiteSuperiorTemperatura`, `LimiteSuperiorLuz`, `LimiteInferiorLuz`) VALUES
(1, '1.00', '2.00', '1.00', '2.00');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tipo_cultura`
--

CREATE TABLE `tipo_cultura` (
  `IDTipoCultura` int(11) NOT NULL,
  `NomeTipoCultura` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `utilizador`
--

CREATE TABLE `utilizador` (
  `EmailUtilizador` varchar(50) NOT NULL,
  `NomeUtilizador` varchar(100) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `CategoriaProfissional` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `variaveis`
--

CREATE TABLE `variaveis` (
  `IDVariavel` int(11) NOT NULL,
  `NomeVariavel` varchar(100) NOT NULL,
  `EmailUtilizador` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `variaveis_medidas`
--

CREATE TABLE `variaveis_medidas` (
  `IDVariaveisMedidas` int(11) NOT NULL,
  `LimiteInferiorVariaveisMedidas` decimal(8,2) DEFAULT NULL,
  `LimiteSuperiorVariaveisMedidas` decimal(8,2) DEFAULT NULL,
  `IDVariavel` int(11) NOT NULL,
  `IDCultura` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categoria_profissional`
--
ALTER TABLE `categoria_profissional`
  ADD PRIMARY KEY (`IDCategoriaProfissional`),
  ADD UNIQUE KEY `NomeCategoriaProfissional_UNIQUE` (`NomeCategoriaProfissional`);

--
-- Indexes for table `cultura`
--
ALTER TABLE `cultura`
  ADD PRIMARY KEY (`IDCultura`),
  ADD UNIQUE KEY `NomeCultura_UNIQUE` (`NomeCultura`),
  ADD KEY `IDTipoCultura` (`IDTipoCultura`),
  ADD KEY `EmailUtilizador` (`EmailUtilizador`);

--
-- Indexes for table `log`
--
ALTER TABLE `log`
  ADD PRIMARY KEY (`IDLog`);

--
-- Indexes for table `medicoes`
--
ALTER TABLE `medicoes`
  ADD PRIMARY KEY (`NumeroMedicao`,`IDVariaveisMedidas`),
  ADD KEY `IDCultura` (`IDCultura`),
  ADD KEY `medicoes_ibfk_1` (`IDVariaveisMedidas`);

--
-- Indexes for table `medicoes_luminosidade_e_temperatura`
--
ALTER TABLE `medicoes_luminosidade_e_temperatura`
  ADD PRIMARY KEY (`IDMedicaoLuminosidadeTemperatura`);

--
-- Indexes for table `sistema`
--
ALTER TABLE `sistema`
  ADD PRIMARY KEY (`IdSistema`);

--
-- Indexes for table `tipo_cultura`
--
ALTER TABLE `tipo_cultura`
  ADD PRIMARY KEY (`IDTipoCultura`),
  ADD UNIQUE KEY `NomeCultura` (`NomeTipoCultura`);

--
-- Indexes for table `utilizador`
--
ALTER TABLE `utilizador`
  ADD PRIMARY KEY (`EmailUtilizador`),
  ADD UNIQUE KEY `NomeUtilizador` (`NomeUtilizador`),
  ADD KEY `CategoriaProfissional` (`CategoriaProfissional`);

--
-- Indexes for table `variaveis`
--
ALTER TABLE `variaveis`
  ADD PRIMARY KEY (`IDVariavel`),
  ADD UNIQUE KEY `NomeVariável_UNIQUE` (`NomeVariavel`),
  ADD KEY `EmailUtilizador` (`EmailUtilizador`);

--
-- Indexes for table `variaveis_medidas`
--
ALTER TABLE `variaveis_medidas`
  ADD PRIMARY KEY (`IDVariaveisMedidas`),
  ADD KEY `variaveis_medidas_ibfk_2` (`IDCultura`),
  ADD KEY `IDVariavel` (`IDVariavel`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categoria_profissional`
--
ALTER TABLE `categoria_profissional`
  MODIFY `IDCategoriaProfissional` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cultura`
--
ALTER TABLE `cultura`
  MODIFY `IDCultura` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `log`
--
ALTER TABLE `log`
  MODIFY `IDLog` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `medicoes`
--
ALTER TABLE `medicoes`
  MODIFY `NumeroMedicao` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `medicoes_luminosidade_e_temperatura`
--
ALTER TABLE `medicoes_luminosidade_e_temperatura`
  MODIFY `IDMedicaoLuminosidadeTemperatura` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sistema`
--
ALTER TABLE `sistema`
  MODIFY `IdSistema` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tipo_cultura`
--
ALTER TABLE `tipo_cultura`
  MODIFY `IDTipoCultura` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `variaveis`
--
ALTER TABLE `variaveis`
  MODIFY `IDVariavel` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `variaveis_medidas`
--
ALTER TABLE `variaveis_medidas`
  MODIFY `IDVariaveisMedidas` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `cultura`
--
ALTER TABLE `cultura`
  ADD CONSTRAINT `cultura_ibfk_2` FOREIGN KEY (`IDTipoCultura`) REFERENCES `tipo_cultura` (`IDTipoCultura`),
  ADD CONSTRAINT `cultura_ibfk_3` FOREIGN KEY (`EmailUtilizador`) REFERENCES `utilizador` (`EmailUtilizador`);

--
-- Limitadores para a tabela `medicoes`
--
ALTER TABLE `medicoes`
  ADD CONSTRAINT `medicoes_ibfk_1` FOREIGN KEY (`IDVariaveisMedidas`) REFERENCES `variaveis_medidas` (`IDVariaveisMedidas`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `medicoes_ibfk_2` FOREIGN KEY (`IDCultura`) REFERENCES `cultura` (`IDCultura`);

--
-- Limitadores para a tabela `utilizador`
--
ALTER TABLE `utilizador`
  ADD CONSTRAINT `utilizador_ibfk_1` FOREIGN KEY (`CategoriaProfissional`) REFERENCES `categoria_profissional` (`IDCategoriaProfissional`);

--
-- Limitadores para a tabela `variaveis`
--
ALTER TABLE `variaveis`
  ADD CONSTRAINT `variaveis_ibfk_1` FOREIGN KEY (`EmailUtilizador`) REFERENCES `utilizador` (`EmailUtilizador`);

--
-- Limitadores para a tabela `variaveis_medidas`
--
ALTER TABLE `variaveis_medidas`
  ADD CONSTRAINT `variaveis_medidas_ibfk_2` FOREIGN KEY (`IDCultura`) REFERENCES `cultura` (`IDCultura`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `variaveis_medidas_ibfk_3` FOREIGN KEY (`IDVariavel`) REFERENCES `variaveis` (`IDVariavel`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
