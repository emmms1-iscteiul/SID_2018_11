-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 25-Fev-2019 às 22:19
-- Versão do servidor: 10.1.37-MariaDB
-- versão do PHP: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `monotorização_de_culturas`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `administrador`
--

CREATE TABLE `administrador` (
  `NomeUtilizador` varchar(100) NOT NULL DEFAULT 'Administrador'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `auditor`
--

CREATE TABLE `auditor` (
  `NomeUtilizador` varchar(100) NOT NULL DEFAULT 'Auditor',
  `IDAuditor` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `cultura`
--

CREATE TABLE `cultura` (
  `IDCultura` int(11) NOT NULL,
  `NomeCultura` varchar(100) NOT NULL,
  `DescriçãoCultura` text,
  `InvestigadorResponsável` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `investigador`
--

CREATE TABLE `investigador` (
  `EmailInvestigador` varchar(50) NOT NULL,
  `NomeInvestigador` varchar(100) NOT NULL,
  `CategoriaProfissional` varchar(300) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `log`
--

CREATE TABLE `log` (
  `IDLog` int(11) NOT NULL,
  `DataHoraOperação` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Utilizador` varchar(100) DEFAULT NULL,
  `Operação` enum('I','U','D') DEFAULT NULL,
  `NomeVariávelAntiga` varchar(100) DEFAULT NULL,
  `NomeVariávelNova` varchar(100) DEFAULT NULL,
  `NomeCulturaAntiga` varchar(100) DEFAULT NULL,
  `NomeCulturaNova` varchar(100) DEFAULT NULL,
  `DesciçãoCulturaAntiga` text,
  `DesciçãoCulturaNova` text,
  `NomeInvestigadorAntigo` varchar(100) DEFAULT NULL,
  `NomeInvestigadorNovo` varchar(100) DEFAULT NULL,
  `CategoriaProfissionalAntiga` varchar(300) DEFAULT NULL,
  `CategoriaProfissionalNova` varchar(300) DEFAULT NULL,
  `LimiteInferiorVariáveisMedidasAntigo` decimal(8,2) DEFAULT NULL,
  `LimiteInferiorVariáveisMedidasNovo` decimal(8,2) DEFAULT NULL,
  `LimiteSuperiorVariáveisMedidasAntigo` decimal(8,2) DEFAULT NULL,
  `LimiteSuperiorVariáveisMedidasNovo` decimal(8,2) DEFAULT NULL,
  `DataHoraMediçãoMediçõesAntiga` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DataHoraMediçãoMediçõesNova` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ValorMediçãoMediçõesAntigo` decimal(8,2) DEFAULT NULL,
  `ValorMediçãoMediçõesNovo` decimal(8,2) DEFAULT NULL,
  `DataHoraMediçãoMediçõesLuminosidadeAntiga` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DataHoraMediçãoMediçõesLuminosidadeNova` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DataHoraMediçãoMediçõesTemperaturaAntiga` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DataHoraMediçãoMediçõesTemperaturaNova` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ValorMediçãoLuminosidadeAntigo` decimal(8,2) DEFAULT NULL,
  `ValorMediçãoLuminosidadeNovo` decimal(8,2) DEFAULT NULL,
  `ValorMediçãoTemperaturaAntigo` decimal(8,2) DEFAULT NULL,
  `ValorMediçãoTemperaturaNovo` decimal(8,2) DEFAULT NULL,
  `LimiteInferiorTemperaturaAntigo` decimal(8,2) DEFAULT NULL,
  `LimiteInferiorTemperaturaNovo` decimal(8,2) DEFAULT NULL,
  `LimiteInferiorLuminosidadeAntigo` decimal(8,2) DEFAULT NULL,
  `LimiteInferiorLuminosidadeNovo` decimal(8,2) DEFAULT NULL,
  `LimiteSuperiorTemperaturaAntigo` decimal(8,2) DEFAULT NULL,
  `LimiteSuperiorTemperaturaNovo` decimal(8,2) DEFAULT NULL,
  `LimiteSuperiorLuminosidadeAntigo` decimal(8,2) DEFAULT NULL,
  `LimiteSuperiorLuminosidadeNovo` decimal(8,2) DEFAULT NULL,
  `IDAuditor` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `medições`
--

CREATE TABLE `medições` (
  `NúmeroMedição` int(11) NOT NULL,
  `DataHoraMedição` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ValorMedição` decimal(8,2) NOT NULL DEFAULT '0.00',
  `IDVariáveisMedidas` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `mediçõesluminosidadeetemperatura`
--

CREATE TABLE `mediçõesluminosidadeetemperatura` (
  `DataHoraMedição` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ValorMediçãoTemperatura` decimal(8,2) NOT NULL,
  `ValorMediçãoHumidade` decimal(8,2) NOT NULL,
  `IDmedição` int(11) NOT NULL,
  `SistemaResponsável` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `sistema`
--

CREATE TABLE `sistema` (
  `LimiteInferiorTemperatura` decimal(8,2) DEFAULT NULL,
  `LimiteSuperiorTemperatura` decimal(8,2) DEFAULT NULL,
  `LimiteSuperiorLuz` decimal(8,2) DEFAULT NULL,
  `LimiteInferiorLuz` decimal(8,2) DEFAULT NULL,
  `NomeSistema` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `variáveis`
--

CREATE TABLE `variáveis` (
  `IDVariável` int(11) NOT NULL,
  `NomeVariável` varchar(100) NOT NULL,
  `AdimnistradorResponsável` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `variáveismedidas`
--

CREATE TABLE `variáveismedidas` (
  `LimiteInferior` decimal(8,2) DEFAULT NULL,
  `LimiteSuperior` decimal(8,2) DEFAULT NULL,
  `IDVariável` int(11) NOT NULL,
  `IDCultura` int(11) NOT NULL,
  `IDVariáveisMedidas` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `administrador`
--
ALTER TABLE `administrador`
  ADD PRIMARY KEY (`NomeUtilizador`);

--
-- Indexes for table `auditor`
--
ALTER TABLE `auditor`
  ADD PRIMARY KEY (`IDAuditor`);

--
-- Indexes for table `cultura`
--
ALTER TABLE `cultura`
  ADD PRIMARY KEY (`IDCultura`),
  ADD KEY `cultura_ibfk_1` (`InvestigadorResponsável`);

--
-- Indexes for table `investigador`
--
ALTER TABLE `investigador`
  ADD PRIMARY KEY (`EmailInvestigador`);

--
-- Indexes for table `log`
--
ALTER TABLE `log`
  ADD PRIMARY KEY (`IDLog`),
  ADD KEY `IDAuditor` (`IDAuditor`);

--
-- Indexes for table `medições`
--
ALTER TABLE `medições`
  ADD PRIMARY KEY (`NúmeroMedição`,`IDVariáveisMedidas`);

--
-- Indexes for table `mediçõesluminosidadeetemperatura`
--
ALTER TABLE `mediçõesluminosidadeetemperatura`
  ADD PRIMARY KEY (`IDmedição`),
  ADD KEY `SistemaResponsável` (`SistemaResponsável`);

--
-- Indexes for table `sistema`
--
ALTER TABLE `sistema`
  ADD PRIMARY KEY (`NomeSistema`);

--
-- Indexes for table `variáveis`
--
ALTER TABLE `variáveis`
  ADD PRIMARY KEY (`IDVariável`),
  ADD KEY `variáveis_ibfk_1` (`AdimnistradorResponsável`);

--
-- Indexes for table `variáveismedidas`
--
ALTER TABLE `variáveismedidas`
  ADD PRIMARY KEY (`IDVariáveisMedidas`),
  ADD KEY `IDVariável` (`IDVariável`),
  ADD KEY `IDCultura` (`IDCultura`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cultura`
--
ALTER TABLE `cultura`
  MODIFY `IDCultura` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `log`
--
ALTER TABLE `log`
  MODIFY `IDLog` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `medições`
--
ALTER TABLE `medições`
  MODIFY `NúmeroMedição` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mediçõesluminosidadeetemperatura`
--
ALTER TABLE `mediçõesluminosidadeetemperatura`
  MODIFY `IDmedição` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `variáveis`
--
ALTER TABLE `variáveis`
  MODIFY `IDVariável` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `variáveismedidas`
--
ALTER TABLE `variáveismedidas`
  MODIFY `IDVariáveisMedidas` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `cultura`
--
ALTER TABLE `cultura`
  ADD CONSTRAINT `cultura_ibfk_1` FOREIGN KEY (`InvestigadorResponsável`) REFERENCES `investigador` (`EmailInvestigador`);

--
-- Limitadores para a tabela `log`
--
ALTER TABLE `log`
  ADD CONSTRAINT `log_ibfk_1` FOREIGN KEY (`IDAuditor`) REFERENCES `auditor` (`IDAuditor`);

--
-- Limitadores para a tabela `mediçõesluminosidadeetemperatura`
--
ALTER TABLE `mediçõesluminosidadeetemperatura`
  ADD CONSTRAINT `mediçõesluminosidadeetemperatura_ibfk_1` FOREIGN KEY (`SistemaResponsável`) REFERENCES `sistema` (`NomeSistema`);

--
-- Limitadores para a tabela `variáveis`
--
ALTER TABLE `variáveis`
  ADD CONSTRAINT `variáveis_ibfk_1` FOREIGN KEY (`AdimnistradorResponsável`) REFERENCES `administrador` (`NomeUtilizador`);

--
-- Limitadores para a tabela `variáveismedidas`
--
ALTER TABLE `variáveismedidas`
  ADD CONSTRAINT `variáveismedidas_ibfk_1` FOREIGN KEY (`IDVariável`) REFERENCES `variáveis` (`IDVariável`),
  ADD CONSTRAINT `variáveismedidas_ibfk_2` FOREIGN KEY (`IDCultura`) REFERENCES `cultura` (`IDCultura`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
