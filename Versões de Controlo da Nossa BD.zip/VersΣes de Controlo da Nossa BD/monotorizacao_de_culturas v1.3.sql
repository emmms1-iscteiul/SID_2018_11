-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 21-Mar-2019 às 19:15
-- Versão do servidor: 10.1.37-MariaDB
-- versão do PHP: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `monotorizacao_de_culturas`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `categoria_profissional`
--

CREATE TABLE `categoria_profissional` (
  `IDCategoriaProfissional` int(11) NOT NULL,
  `NomeCategoriaProfissional` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `cultura`
--

CREATE TABLE `cultura` (
  `IDCultura` int(11) NOT NULL,
  `NomeCultura` varchar(100) NOT NULL,
  `DescriçãoCultura` text,
  `EmailUtilizador` varchar(50) NOT NULL,
  `IDTipoCultura` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `log`
--

CREATE TABLE `log` (
  `IDLog` int(11) NOT NULL,
  `DataHoraOperação` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `UtilizadorOperação` varchar(100) NOT NULL,
  `Operação` enum('S','I','U','D') NOT NULL,
  `NomeVariávelAntiga` varchar(100) DEFAULT NULL,
  `NomeVariávelNova` varchar(100) DEFAULT NULL,
  `NomeCulturaAntiga` varchar(100) DEFAULT NULL,
  `NomeCulturaNova` varchar(100) DEFAULT NULL,
  `DesciçãoCulturaAntiga` text,
  `DesciçãoCulturaNova` text,
  `NomeUtilizadorAntigo` varchar(100) DEFAULT NULL,
  `NomeUtilizadorNovo` varchar(100) DEFAULT NULL,
  `TipoUtilizadorAntigo` enum('Administrador','Auditor','Investigador') DEFAULT NULL,
  `TipoUtilizadorNovo` enum('Administrador','Auditor','Investigador') DEFAULT NULL,
  `CategoriaProfissionalUtilizadorAntiga` varchar(300) DEFAULT NULL,
  `CategoriaProfissionalUtilizadorNova` varchar(300) DEFAULT NULL,
  `LimiteInferiorVariáveisMedidasAntigo` decimal(8,2) DEFAULT NULL,
  `LimiteInferiorVariáveisMedidasNovo` decimal(8,2) DEFAULT NULL,
  `LimiteSuperiorVariáveisMedidasAntigo` decimal(8,2) DEFAULT NULL,
  `LimiteSuperiorVariáveisMedidasNovo` decimal(8,2) DEFAULT NULL,
  `DataHoraMediçãoMediçõesAntiga` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DataHoraMediçãoMediçõesNova` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ValorMediçãoMediçõesAntigo` decimal(8,2) DEFAULT NULL,
  `ValorMediçãoMediçõesNovo` decimal(8,2) DEFAULT NULL,
  `DataHoraMediçãoMediçõesLuminosidadeTemperaturaAntiga` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DataHoraMediçãoMediçõesLuminosidadeTemperaturaNova` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ValorMediçãoLuminosidadeAntigo` decimal(8,2) DEFAULT NULL,
  `ValorMediçãoLuminosidadeNovo` decimal(8,2) DEFAULT NULL,
  `ValorMediçãoTemperaturaAntigo` decimal(8,2) DEFAULT NULL,
  `ValorMediçãoTemperaturaNovo` decimal(8,2) DEFAULT NULL,
  `LimiteInferiorTemperaturaSistemaAntigo` decimal(8,2) DEFAULT NULL,
  `LimiteInferiorTemperaturaSistemaNovo` decimal(8,2) DEFAULT NULL,
  `LimiteInferiorLuminosidadeSistemaAntigo` decimal(8,2) DEFAULT NULL,
  `LimiteInferiorLuminosidadeSistemaNovo` decimal(8,2) DEFAULT NULL,
  `LimiteSuperiorTemperaturaSistemaAntigo` decimal(8,2) DEFAULT NULL,
  `LimiteSuperiorTemperaturaSistemaNovo` decimal(8,2) DEFAULT NULL,
  `LimiteSuperiorLuminosidadeSistemaAntigo` decimal(8,2) DEFAULT NULL,
  `LimiteSuperiorLuminosidadeSistemaNovo` decimal(8,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `medicoes`
--

CREATE TABLE `medicoes` (
  `NúmeroMedição` int(11) NOT NULL,
  `DataHoraMediçãoMedições` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ValorMediçãoMedições` decimal(8,2) NOT NULL,
  `IDVariáveisMedidas` int(11) NOT NULL,
  `IDCultura` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `medicoes_luminosidade_e_temperatura`
--

CREATE TABLE `medicoes_luminosidade_e_temperatura` (
  `DataHoraMediçãoLuminosidadeTemperatura` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ValorMediçãoTemperatura` decimal(8,2) NOT NULL,
  `ValorMediçãoLuminosidade` decimal(8,2) NOT NULL,
  `IDmedição` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `sistema`
--

CREATE TABLE `sistema` (
  `LimiteInferiorTemperatura` decimal(8,2) NOT NULL,
  `LimiteSuperiorTemperatura` decimal(8,2) NOT NULL,
  `LimiteSuperiorLuz` decimal(8,2) NOT NULL,
  `LimiteInferiorLuz` decimal(8,2) NOT NULL,
  `IdSistema` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `sistema`
--

INSERT INTO `sistema` (`LimiteInferiorTemperatura`, `LimiteSuperiorTemperatura`, `LimiteSuperiorLuz`, `LimiteInferiorLuz`, `IdSistema`) VALUES
('1.00', '2.00', '1.00', '2.00', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tipo_cultura`
--

CREATE TABLE `tipo_cultura` (
  `IDTipoCultura` int(11) NOT NULL,
  `NomeCultura` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `utilizador`
--

CREATE TABLE `utilizador` (
  `EmailUtilizador` varchar(50) NOT NULL,
  `NomeUtilizador` varchar(100) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `CategoriaProfissional` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `variaveis`
--

CREATE TABLE `variaveis` (
  `IDVariável` int(11) NOT NULL,
  `NomeVariável` varchar(100) NOT NULL,
  `EmailUtilizador` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `variaveis_medidas`
--

CREATE TABLE `variaveis_medidas` (
  `LimiteInferiorVariáveisMedidas` decimal(8,2) DEFAULT NULL,
  `LimiteSuperiorVariáveisMedidas` decimal(8,2) DEFAULT NULL,
  `IDVariáveisMedidas` int(11) NOT NULL,
  `IDVariável` int(11) NOT NULL,
  `IDCultura` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categoria_profissional`
--
ALTER TABLE `categoria_profissional`
  ADD PRIMARY KEY (`IDCategoriaProfissional`),
  ADD UNIQUE KEY `NomeCategoriaProfissional_UNIQUE` (`NomeCategoriaProfissional`);

--
-- Indexes for table `cultura`
--
ALTER TABLE `cultura`
  ADD PRIMARY KEY (`IDCultura`),
  ADD UNIQUE KEY `NomeCultura_UNIQUE` (`NomeCultura`),
  ADD KEY `IDTipoCultura` (`IDTipoCultura`),
  ADD KEY `EmailUtilizador` (`EmailUtilizador`);

--
-- Indexes for table `log`
--
ALTER TABLE `log`
  ADD PRIMARY KEY (`IDLog`);

--
-- Indexes for table `medicoes`
--
ALTER TABLE `medicoes`
  ADD PRIMARY KEY (`NúmeroMedição`,`IDVariáveisMedidas`),
  ADD KEY `medicoes_ibfk_1` (`IDVariáveisMedidas`),
  ADD KEY `IDCultura` (`IDCultura`);

--
-- Indexes for table `medicoes_luminosidade_e_temperatura`
--
ALTER TABLE `medicoes_luminosidade_e_temperatura`
  ADD PRIMARY KEY (`IDmedição`);

--
-- Indexes for table `sistema`
--
ALTER TABLE `sistema`
  ADD PRIMARY KEY (`IdSistema`);

--
-- Indexes for table `tipo_cultura`
--
ALTER TABLE `tipo_cultura`
  ADD PRIMARY KEY (`IDTipoCultura`),
  ADD UNIQUE KEY `NomeCultura` (`NomeCultura`);

--
-- Indexes for table `utilizador`
--
ALTER TABLE `utilizador`
  ADD PRIMARY KEY (`EmailUtilizador`),
  ADD UNIQUE KEY `NomeUtilizador` (`NomeUtilizador`),
  ADD KEY `CategoriaProfissional` (`CategoriaProfissional`);

--
-- Indexes for table `variaveis`
--
ALTER TABLE `variaveis`
  ADD PRIMARY KEY (`IDVariável`),
  ADD UNIQUE KEY `NomeVariável_UNIQUE` (`NomeVariável`),
  ADD KEY `EmailUtilizador` (`EmailUtilizador`);

--
-- Indexes for table `variaveis_medidas`
--
ALTER TABLE `variaveis_medidas`
  ADD PRIMARY KEY (`IDVariáveisMedidas`),
  ADD KEY `variaveis_medidas_ibfk_1` (`IDVariável`),
  ADD KEY `variaveis_medidas_ibfk_2` (`IDCultura`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categoria_profissional`
--
ALTER TABLE `categoria_profissional`
  MODIFY `IDCategoriaProfissional` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cultura`
--
ALTER TABLE `cultura`
  MODIFY `IDCultura` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `log`
--
ALTER TABLE `log`
  MODIFY `IDLog` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `medicoes`
--
ALTER TABLE `medicoes`
  MODIFY `NúmeroMedição` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `medicoes_luminosidade_e_temperatura`
--
ALTER TABLE `medicoes_luminosidade_e_temperatura`
  MODIFY `IDmedição` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sistema`
--
ALTER TABLE `sistema`
  MODIFY `IdSistema` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tipo_cultura`
--
ALTER TABLE `tipo_cultura`
  MODIFY `IDTipoCultura` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `variaveis`
--
ALTER TABLE `variaveis`
  MODIFY `IDVariável` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `variaveis_medidas`
--
ALTER TABLE `variaveis_medidas`
  MODIFY `IDVariáveisMedidas` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `cultura`
--
ALTER TABLE `cultura`
  ADD CONSTRAINT `cultura_ibfk_2` FOREIGN KEY (`IDTipoCultura`) REFERENCES `tipo_cultura` (`IDTipoCultura`),
  ADD CONSTRAINT `cultura_ibfk_3` FOREIGN KEY (`EmailUtilizador`) REFERENCES `utilizador` (`EmailUtilizador`);

--
-- Limitadores para a tabela `medicoes`
--
ALTER TABLE `medicoes`
  ADD CONSTRAINT `medicoes_ibfk_1` FOREIGN KEY (`IDVariáveisMedidas`) REFERENCES `variaveis_medidas` (`IDVariáveisMedidas`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `medicoes_ibfk_2` FOREIGN KEY (`IDCultura`) REFERENCES `cultura` (`IDCultura`);

--
-- Limitadores para a tabela `utilizador`
--
ALTER TABLE `utilizador`
  ADD CONSTRAINT `utilizador_ibfk_1` FOREIGN KEY (`CategoriaProfissional`) REFERENCES `categoria_profissional` (`IDCategoriaProfissional`);

--
-- Limitadores para a tabela `variaveis`
--
ALTER TABLE `variaveis`
  ADD CONSTRAINT `variaveis_ibfk_1` FOREIGN KEY (`EmailUtilizador`) REFERENCES `utilizador` (`EmailUtilizador`);

--
-- Limitadores para a tabela `variaveis_medidas`
--
ALTER TABLE `variaveis_medidas`
  ADD CONSTRAINT `variaveis_medidas_ibfk_1` FOREIGN KEY (`IDVariável`) REFERENCES `variaveis` (`IDVariável`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `variaveis_medidas_ibfk_2` FOREIGN KEY (`IDCultura`) REFERENCES `cultura` (`IDCultura`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
