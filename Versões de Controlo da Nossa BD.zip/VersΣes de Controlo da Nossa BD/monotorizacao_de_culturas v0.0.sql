-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 23-Fev-2019 às 01:42
-- Versão do servidor: 10.1.37-MariaDB
-- versão do PHP: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `monotorização_de_culturas`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `administrador`
--

CREATE TABLE `administrador` (
  `NomeUtilizador` varchar(100) NOT NULL DEFAULT 'Administrador'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `auditor`
--

CREATE TABLE `auditor` (
  `NomeUtilizador` varchar(100) NOT NULL DEFAULT 'Auditor',
  `ID` int(11) NOT NULL,
  `IDUtilizador` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `cultura`
--

CREATE TABLE `cultura` (
  `IDCultura` int(11) NOT NULL,
  `NomeCultura` varchar(100) NOT NULL,
  `DescriçãoCultura` text,
  `EmailInvestigador` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `investigador`
--

CREATE TABLE `investigador` (
  `Email` varchar(50) NOT NULL,
  `NomeInvestigador` varchar(100) NOT NULL,
  `CategoriaProfissional` varchar(300) DEFAULT NULL,
  `IDUtilizador` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `log`
--

CREATE TABLE `log` (
  `IDLog` int(11) NOT NULL,
  `DataHoraOperação` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Utilizador` varchar(100) DEFAULT NULL,
  `Operação` enum('I','U','D') DEFAULT NULL,
  `NomeVariávelAntiga` varchar(100) DEFAULT NULL,
  `NomeVariávelNova` varchar(100) DEFAULT NULL,
  `NomeCulturaAntiga` varchar(100) DEFAULT NULL,
  `NomeCulturaNova` varchar(100) DEFAULT NULL,
  `DesciçãoCulturaAntiga` text,
  `DesciçãoCulturaNova` text,
  `NomeInvestigadorAntigo` varchar(100) DEFAULT NULL,
  `NomeInvestigadorNovo` varchar(100) DEFAULT NULL,
  `CategoriaProfissionalAntiga` varchar(300) DEFAULT NULL,
  `CategoriaProfissionalNova` varchar(300) DEFAULT NULL,
  `LimiteInferiorVariáveisMedidasAntigo` decimal(8,2) DEFAULT NULL,
  `LimiteInferiorVariáveisMedidasNovo` decimal(8,2) DEFAULT NULL,
  `LimiteSuperiorVariáveisMedidasAntigo` decimal(8,2) DEFAULT NULL,
  `LimiteSuperiorVariáveisMedidasNovo` decimal(8,2) DEFAULT NULL,
  `DataHoraMediçãoMediçõesAntiga` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DataHoraMediçãoMediçõesNova` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ValorMediçãoMediçõesAntigo` decimal(8,2) DEFAULT NULL,
  `ValorMediçãoMediçõesNovo` decimal(8,2) DEFAULT NULL,
  `DataHoraMediçãoMediçõesLuminosidadeAntiga` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DataHoraMediçãoMediçõesLuminosidadeNova` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DataHoraMediçãoMediçõesTemperaturaAntiga` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DataHoraMediçãoMediçõesTemperaturaNova` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ValorMediçãoLuminosidadeAntigo` decimal(8,2) DEFAULT NULL,
  `ValorMediçãoLuminosidadeNovo` decimal(8,2) DEFAULT NULL,
  `ValorMediçãoTemperaturaAntigo` decimal(8,2) DEFAULT NULL,
  `ValorMediçãoTemperaturaNovo` decimal(8,2) DEFAULT NULL,
  `LimiteInferiorTemperaturaAntigo` decimal(8,2) DEFAULT NULL,
  `LimiteInferiorTemperaturaNovo` decimal(8,2) DEFAULT NULL,
  `LimiteInferiorLuminosidadeAntigo` decimal(8,2) DEFAULT NULL,
  `LimiteInferiorLuminosidadeNovo` decimal(8,2) DEFAULT NULL,
  `LimiteSuperiorTemperaturaAntigo` decimal(8,2) DEFAULT NULL,
  `LimiteSuperiorTemperaturaNovo` decimal(8,2) DEFAULT NULL,
  `LimiteSuperiorLuminosidadeAntigo` decimal(8,2) DEFAULT NULL,
  `LimiteSuperiorLuminosidadeNovo` decimal(8,2) DEFAULT NULL,
  `IDAuditor` int(11) NOT NULL,
  `IDUtilizador` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `medições`
--

CREATE TABLE `medições` (
  `NúmeroMedição` int(11) NOT NULL,
  `DataHoraMedição` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ValorMedição` decimal(8,2) NOT NULL DEFAULT '0.00',
  `IDVariáveisMedidas` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `mediçõesluminosidadeetemperatura`
--

CREATE TABLE `mediçõesluminosidadeetemperatura` (
  `IDMedição` int(11) NOT NULL,
  `DataHoraMedição` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ValorMediçãoTemperatura` decimal(8,2) NOT NULL,
  `ValorMediçãoHumidade` decimal(8,2) NOT NULL,
  `IDSistema` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `sistema`
--

CREATE TABLE `sistema` (
  `LimiteInferiorTemperatura` decimal(8,2) DEFAULT NULL,
  `LimiteSuperiorTemperatura` decimal(8,2) DEFAULT NULL,
  `LimiteSuperiorLuz` decimal(8,2) DEFAULT NULL,
  `LimiteInferiorLuz` decimal(8,2) DEFAULT NULL,
  `ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `utilizador`
--

CREATE TABLE `utilizador` (
  `NomeUtilizador` varchar(100) NOT NULL,
  `TipoUtilizador` enum('Investigador','Auditor','Sensor de Temperatura','Sensor de Luminosidade') DEFAULT NULL,
  `NomeAdministrador` varchar(100) NOT NULL,
  `ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `variáveis`
--

CREATE TABLE `variáveis` (
  `IDVariável` int(11) NOT NULL,
  `NomeVariável` varchar(100) NOT NULL,
  `NomeAdministrador` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `variáveismedidas`
--

CREATE TABLE `variáveismedidas` (
  `LimiteInferior` decimal(8,2) DEFAULT NULL,
  `LimiteSuperior` decimal(8,2) DEFAULT NULL,
  `ID` int(11) NOT NULL,
  `IDVariável` int(11) NOT NULL,
  `IDCultura` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `administrador`
--
ALTER TABLE `administrador`
  ADD PRIMARY KEY (`NomeUtilizador`);

--
-- Indexes for table `auditor`
--
ALTER TABLE `auditor`
  ADD PRIMARY KEY (`ID`,`IDUtilizador`);

--
-- Indexes for table `cultura`
--
ALTER TABLE `cultura`
  ADD PRIMARY KEY (`IDCultura`),
  ADD KEY `EmailInvestigador` (`EmailInvestigador`);

--
-- Indexes for table `investigador`
--
ALTER TABLE `investigador`
  ADD PRIMARY KEY (`Email`,`IDUtilizador`);

--
-- Indexes for table `log`
--
ALTER TABLE `log`
  ADD PRIMARY KEY (`IDLog`),
  ADD KEY `IDAuditor` (`IDAuditor`);

--
-- Indexes for table `medições`
--
ALTER TABLE `medições`
  ADD PRIMARY KEY (`NúmeroMedição`,`IDVariáveisMedidas`);

--
-- Indexes for table `mediçõesluminosidadeetemperatura`
--
ALTER TABLE `mediçõesluminosidadeetemperatura`
  ADD PRIMARY KEY (`IDMedição`),
  ADD UNIQUE KEY `IDMedição` (`IDMedição`),
  ADD KEY `IDSistema` (`IDSistema`);

--
-- Indexes for table `sistema`
--
ALTER TABLE `sistema`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `ID` (`ID`);

--
-- Indexes for table `utilizador`
--
ALTER TABLE `utilizador`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `NomeAdministrador` (`NomeAdministrador`);

--
-- Indexes for table `variáveis`
--
ALTER TABLE `variáveis`
  ADD PRIMARY KEY (`IDVariável`),
  ADD KEY `NomeAdministrador` (`NomeAdministrador`);

--
-- Indexes for table `variáveismedidas`
--
ALTER TABLE `variáveismedidas`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `ID` (`ID`),
  ADD KEY `IDVariável` (`IDVariável`),
  ADD KEY `IDCultura` (`IDCultura`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cultura`
--
ALTER TABLE `cultura`
  MODIFY `IDCultura` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `log`
--
ALTER TABLE `log`
  MODIFY `IDLog` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `medições`
--
ALTER TABLE `medições`
  MODIFY `NúmeroMedição` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mediçõesluminosidadeetemperatura`
--
ALTER TABLE `mediçõesluminosidadeetemperatura`
  MODIFY `IDMedição` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sistema`
--
ALTER TABLE `sistema`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `utilizador`
--
ALTER TABLE `utilizador`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `variáveis`
--
ALTER TABLE `variáveis`
  MODIFY `IDVariável` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `variáveismedidas`
--
ALTER TABLE `variáveismedidas`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `cultura`
--
ALTER TABLE `cultura`
  ADD CONSTRAINT `cultura_ibfk_1` FOREIGN KEY (`EmailInvestigador`) REFERENCES `investigador` (`Email`);

--
-- Limitadores para a tabela `log`
--
ALTER TABLE `log`
  ADD CONSTRAINT `log_ibfk_1` FOREIGN KEY (`IDAuditor`) REFERENCES `auditor` (`ID`);

--
-- Limitadores para a tabela `mediçõesluminosidadeetemperatura`
--
ALTER TABLE `mediçõesluminosidadeetemperatura`
  ADD CONSTRAINT `mediçõesluminosidadeetemperatura_ibfk_1` FOREIGN KEY (`IDSistema`) REFERENCES `sistema` (`ID`);

--
-- Limitadores para a tabela `utilizador`
--
ALTER TABLE `utilizador`
  ADD CONSTRAINT `utilizador_ibfk_1` FOREIGN KEY (`NomeAdministrador`) REFERENCES `administrador` (`NomeUtilizador`);

--
-- Limitadores para a tabela `variáveis`
--
ALTER TABLE `variáveis`
  ADD CONSTRAINT `variáveis_ibfk_1` FOREIGN KEY (`NomeAdministrador`) REFERENCES `administrador` (`NomeUtilizador`);

--
-- Limitadores para a tabela `variáveismedidas`
--
ALTER TABLE `variáveismedidas`
  ADD CONSTRAINT `variáveismedidas_ibfk_1` FOREIGN KEY (`IDVariável`) REFERENCES `variáveis` (`IDVariável`),
  ADD CONSTRAINT `variáveismedidas_ibfk_2` FOREIGN KEY (`IDCultura`) REFERENCES `cultura` (`IDCultura`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
