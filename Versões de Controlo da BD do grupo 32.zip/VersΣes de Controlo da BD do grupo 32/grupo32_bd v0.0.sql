-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 20-Mar-2019 às 22:19
-- Versão do servidor: 10.1.37-MariaDB
-- versão do PHP: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `grupo32_bd`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `categoriaprofissional`
--

CREATE TABLE `categoriaprofissional` (
  `IdCategoriaProfissional` int(11) NOT NULL,
  `NomeCategoriaProfissional` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `categoriaprofissional`
--

INSERT INTO `categoriaprofissional` (`IdCategoriaProfissional`, `NomeCategoriaProfissional`) VALUES
(1, 'Admin');

-- --------------------------------------------------------

--
-- Estrutura da tabela `cultura`
--

CREATE TABLE `cultura` (
  `IdCultura` int(11) NOT NULL,
  `NomeCultura` varchar(100) NOT NULL,
  `DescriçãoCultura` text,
  `TipoCultura` int(11) NOT NULL,
  `IdUtilizador` int(11) NOT NULL,
  `IdTipoCultura` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `medicao`
--

CREATE TABLE `medicao` (
  `IdVariávelMedida` int(11) NOT NULL,
  `IdMedição` int(11) NOT NULL,
  `DataHoraMedição` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ValorMedição` decimal(8,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `medicaoluminosidade`
--

CREATE TABLE `medicaoluminosidade` (
  `DataHoraMedição` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ValorMediçãoLuminosidade` decimal(8,2) NOT NULL,
  `IdMedição` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `medicaotemperatura`
--

CREATE TABLE `medicaotemperatura` (
  `DataHoraMedição` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ValorMediçãoTemperatura` decimal(8,2) NOT NULL,
  `IdMedição` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `sistema`
--

CREATE TABLE `sistema` (
  `LimiteSuperiorTemperatura` decimal(8,2) NOT NULL,
  `LimiteInferiorTemperatura` decimal(8,2) NOT NULL,
  `LimiteSuperiorLuminosidade` decimal(8,2) NOT NULL,
  `LimiteInferiorLuminosidade` decimal(8,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tipocultura`
--

CREATE TABLE `tipocultura` (
  `IdTipoCultura` int(11) NOT NULL,
  `NomeCultura` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `utilizador`
--

CREATE TABLE `utilizador` (
  `IdUtilizador` int(11) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `NomeUtilizador` varchar(100) NOT NULL,
  `CategoriaProfissional` int(11) NOT NULL,
  `Password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `utilizador`
--

INSERT INTO `utilizador` (`IdUtilizador`, `Email`, `NomeUtilizador`, `CategoriaProfissional`, `Password`) VALUES
(1, 'adasss@gmail.com', 'inv1', 1, 'dasdsads');

-- --------------------------------------------------------

--
-- Estrutura da tabela `variavel`
--

CREATE TABLE `variavel` (
  `IdVariável` int(11) NOT NULL,
  `NomeVariável` varchar(100) NOT NULL,
  `IdUtilizador` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `variavelmedida`
--

CREATE TABLE `variavelmedida` (
  `LimiteInferior` decimal(8,2) NOT NULL,
  `LimiteSuperior` decimal(8,2) NOT NULL,
  `IdCultura` int(11) NOT NULL,
  `IdVariável` int(11) NOT NULL,
  `IdVariávelMedida` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `[logtemp]cultura`
--

CREATE TABLE `[logtemp]cultura` (
  `IdLog` int(11) NOT NULL,
  `Utilizador` varchar(100) NOT NULL,
  `DataHoraLog` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Operação` enum('S','I','U','D') NOT NULL,
  `IdCultura` int(11) NOT NULL,
  `NomeCultura` varchar(100) DEFAULT NULL,
  `DescriçãoCultura` text,
  `TipoCultura` int(11) NOT NULL,
  `IdUtilizador` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `[logtemp]medicao`
--

CREATE TABLE `[logtemp]medicao` (
  `IdLog` int(11) NOT NULL,
  `Utilizador` varchar(100) NOT NULL,
  `DataHoraLog` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Operação` enum('S','I','U','D') NOT NULL,
  `IdMedição` int(11) NOT NULL,
  `DataHoraMedição` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `ValorMedição` decimal(8,2) DEFAULT NULL,
  `IdVariávelMedida` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `[logtemp]medicao_luminosidade`
--

CREATE TABLE `[logtemp]medicao_luminosidade` (
  `IdLog` int(11) NOT NULL,
  `Utilizador` varchar(100) NOT NULL,
  `DataHoraLog` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Operação` enum('S','I','U','D') NOT NULL,
  `DataHoraMedição` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `ValorMediçãoLuminosidade` decimal(8,2) DEFAULT NULL,
  `IdMedição` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `[logtemp]medicao_temperatura`
--

CREATE TABLE `[logtemp]medicao_temperatura` (
  `IdLog` int(11) NOT NULL,
  `Utilizador` varchar(100) NOT NULL,
  `DataHoraLog` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Operação` enum('S','I','U','D') NOT NULL,
  `IdMedição` int(11) NOT NULL,
  `DataHoraMediçãoTemperatura` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ValorMediçãoTemperatura` decimal(8,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `[logtemp]sistema`
--

CREATE TABLE `[logtemp]sistema` (
  `IdLog` int(11) NOT NULL,
  `Utilizador` varchar(100) NOT NULL,
  `DataHoraLog` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Operação` enum('S','I','U','D') NOT NULL,
  `LimiteSuperiorTemperatura` decimal(8,2) DEFAULT NULL,
  `LimiteInferiorTemperatura` decimal(8,2) DEFAULT NULL,
  `LimiteSuperiorLuminosidade` decimal(8,2) DEFAULT NULL,
  `LimiteInferiorLuminosidade` decimal(8,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `[logtemp]tipo_cultura`
--

CREATE TABLE `[logtemp]tipo_cultura` (
  `IdLog` int(11) NOT NULL,
  `Utilizador` varchar(100) NOT NULL,
  `DataHoraLog` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Operação` enum('S','I','U','D') NOT NULL,
  `IdTipoCultura` int(11) NOT NULL,
  `NomeTipoCultura` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `[logtemp]utilizador`
--

CREATE TABLE `[logtemp]utilizador` (
  `IdLog` int(11) NOT NULL,
  `Utilizador` varchar(100) NOT NULL,
  `DataHoraLog` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Operação` enum('S','I','U','D') NOT NULL,
  `Password` varchar(50) NOT NULL,
  `IdUtilizador` int(11) NOT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `NomeUtilizador` varchar(100) DEFAULT NULL,
  `CategoriaProfissional` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `[logtemp]variavel`
--

CREATE TABLE `[logtemp]variavel` (
  `IdLog` int(11) NOT NULL,
  `Utilizador` varchar(100) NOT NULL,
  `DataHoraLog` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Operação` enum('S','I','U','D') NOT NULL,
  `IdVariável` int(11) NOT NULL,
  `NomeVariável` varchar(100) DEFAULT NULL,
  `IdCultura` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `[logtemp]variavel_medida`
--

CREATE TABLE `[logtemp]variavel_medida` (
  `IdLog` int(11) NOT NULL,
  `Utilizador` varchar(100) NOT NULL,
  `DataHoraLog` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Operação` enum('S','I','U','D') NOT NULL,
  `LimiteInferior` decimal(8,2) DEFAULT NULL,
  `LimiteSuperior` decimal(8,2) DEFAULT NULL,
  `IdCultura` int(11) NOT NULL,
  `IdVariável` int(11) NOT NULL,
  `IdVariávelMedida` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `[log]cultura`
--

CREATE TABLE `[log]cultura` (
  `IdLog` int(11) NOT NULL,
  `Utilizador` varchar(100) NOT NULL,
  `DataHoraLog` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Operação` enum('S','I','U','D') NOT NULL,
  `IdCultura` int(11) NOT NULL,
  `NomeCultura` varchar(100) DEFAULT NULL,
  `DescriçãoCultura` text,
  `TipoCultura` int(11) NOT NULL,
  `IdUtilizador` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `[log]medicao`
--

CREATE TABLE `[log]medicao` (
  `IdLog` int(11) NOT NULL,
  `Utilizador` varchar(100) NOT NULL,
  `DataHoraLog` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Operação` enum('S','I','U','D') NOT NULL,
  `IdMedição` int(11) NOT NULL,
  `DataHoraMedição` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `ValorMedição` decimal(8,2) DEFAULT NULL,
  `IdVariávelMedida` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `[log]medicao_luminosidade`
--

CREATE TABLE `[log]medicao_luminosidade` (
  `IdLog` int(11) NOT NULL,
  `Utilizador` varchar(100) NOT NULL,
  `DataHoraLog` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Operação` enum('S','I','U','D') NOT NULL,
  `DataHoraMedição` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `ValorMediçãoLuminosidade` decimal(8,2) DEFAULT NULL,
  `IdMedição` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `[log]medicao_temperatura`
--

CREATE TABLE `[log]medicao_temperatura` (
  `IdLog` int(11) NOT NULL,
  `Utilizador` varchar(100) NOT NULL,
  `DataHoraLog` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Operação` enum('S','I','U','D') NOT NULL,
  `IdMedição` int(11) NOT NULL,
  `DataHoraMediçãoTemperatura` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ValorMediçãoTemperatura` decimal(8,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `[log]sistema`
--

CREATE TABLE `[log]sistema` (
  `IdLog` int(11) NOT NULL,
  `Utilizador` varchar(100) NOT NULL,
  `DataHoraLog` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Operação` enum('S','I','U','D') NOT NULL,
  `LimiteSuperiorTemperatura` decimal(8,2) DEFAULT NULL,
  `LimiteInferiorTemperatura` decimal(8,2) DEFAULT NULL,
  `LimiteSuperiorLuminosidade` decimal(8,2) DEFAULT NULL,
  `LimiteInferiorLuminosidade` decimal(8,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `[log]tipo_cultura`
--

CREATE TABLE `[log]tipo_cultura` (
  `IdLog` int(11) NOT NULL,
  `Utilizador` varchar(100) NOT NULL,
  `DataHoraLog` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Operação` enum('S','I','U','D') NOT NULL,
  `IdTipoCultura` int(11) NOT NULL,
  `NomeTipoCultura` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `[log]utilizador`
--

CREATE TABLE `[log]utilizador` (
  `IdLog` int(11) NOT NULL,
  `Utilizador` varchar(100) NOT NULL,
  `DataHoraLog` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Operação` enum('S','I','U','D') NOT NULL,
  `Password` varchar(50) NOT NULL,
  `IdUtilizador` int(11) NOT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `NomeUtilizador` varchar(100) DEFAULT NULL,
  `CategoriaProfissional` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `[log]variavel`
--

CREATE TABLE `[log]variavel` (
  `IdLog` int(11) NOT NULL,
  `Utilizador` varchar(100) NOT NULL,
  `DataHoraLog` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Operação` enum('S','I','U','D') NOT NULL,
  `IdVariável` int(11) NOT NULL,
  `NomeVariável` varchar(100) DEFAULT NULL,
  `IdCultura` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `[log]variavel_medida`
--

CREATE TABLE `[log]variavel_medida` (
  `IdLog` int(11) NOT NULL,
  `Utilizador` varchar(100) NOT NULL,
  `DataHoraLog` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Operação` enum('S','I','U','D') NOT NULL,
  `LimiteInferior` decimal(8,2) DEFAULT NULL,
  `LimiteSuperior` decimal(8,2) DEFAULT NULL,
  `IdCultura` int(11) NOT NULL,
  `IdVariável` int(11) NOT NULL,
  `IdVariávelMedida` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categoriaprofissional`
--
ALTER TABLE `categoriaprofissional`
  ADD PRIMARY KEY (`IdCategoriaProfissional`),
  ADD UNIQUE KEY `NomeCategoriaProfissional` (`NomeCategoriaProfissional`);

--
-- Indexes for table `cultura`
--
ALTER TABLE `cultura`
  ADD PRIMARY KEY (`IdCultura`),
  ADD UNIQUE KEY `NomeCultura_UNIQUE` (`NomeCultura`),
  ADD KEY `IdTipoCultura` (`IdTipoCultura`),
  ADD KEY `IdUtilizador` (`IdUtilizador`);

--
-- Indexes for table `medicao`
--
ALTER TABLE `medicao`
  ADD PRIMARY KEY (`IdVariávelMedida`,`IdMedição`);

--
-- Indexes for table `medicaoluminosidade`
--
ALTER TABLE `medicaoluminosidade`
  ADD PRIMARY KEY (`IdMedição`);

--
-- Indexes for table `medicaotemperatura`
--
ALTER TABLE `medicaotemperatura`
  ADD PRIMARY KEY (`IdMedição`);

--
-- Indexes for table `tipocultura`
--
ALTER TABLE `tipocultura`
  ADD PRIMARY KEY (`IdTipoCultura`),
  ADD UNIQUE KEY `NomeCultura_UNIQUE` (`NomeCultura`);

--
-- Indexes for table `utilizador`
--
ALTER TABLE `utilizador`
  ADD PRIMARY KEY (`IdUtilizador`),
  ADD UNIQUE KEY `unique_index` (`Email`,`Password`),
  ADD UNIQUE KEY `Email_UNIQUE` (`Email`),
  ADD UNIQUE KEY `Password_UNIQUE` (`Password`),
  ADD KEY `CategoriaProfissional` (`CategoriaProfissional`);

--
-- Indexes for table `variavel`
--
ALTER TABLE `variavel`
  ADD PRIMARY KEY (`IdVariável`),
  ADD KEY `IdUtilizador` (`IdUtilizador`);

--
-- Indexes for table `variavelmedida`
--
ALTER TABLE `variavelmedida`
  ADD PRIMARY KEY (`IdVariávelMedida`),
  ADD KEY `IdCultura` (`IdCultura`),
  ADD KEY `IdVariável` (`IdVariável`);

--
-- Indexes for table `[log]cultura`
--
ALTER TABLE `[log]cultura`
  ADD PRIMARY KEY (`IdLog`);

--
-- Indexes for table `[log]medicao`
--
ALTER TABLE `[log]medicao`
  ADD PRIMARY KEY (`IdLog`);

--
-- Indexes for table `[log]medicao_luminosidade`
--
ALTER TABLE `[log]medicao_luminosidade`
  ADD PRIMARY KEY (`IdLog`);

--
-- Indexes for table `[log]medicao_temperatura`
--
ALTER TABLE `[log]medicao_temperatura`
  ADD PRIMARY KEY (`IdLog`);

--
-- Indexes for table `[log]sistema`
--
ALTER TABLE `[log]sistema`
  ADD PRIMARY KEY (`IdLog`);

--
-- Indexes for table `[log]tipo_cultura`
--
ALTER TABLE `[log]tipo_cultura`
  ADD PRIMARY KEY (`IdLog`);

--
-- Indexes for table `[log]utilizador`
--
ALTER TABLE `[log]utilizador`
  ADD PRIMARY KEY (`IdLog`);

--
-- Indexes for table `[log]variavel`
--
ALTER TABLE `[log]variavel`
  ADD PRIMARY KEY (`IdLog`);

--
-- Indexes for table `[log]variavel_medida`
--
ALTER TABLE `[log]variavel_medida`
  ADD PRIMARY KEY (`IdLog`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categoriaprofissional`
--
ALTER TABLE `categoriaprofissional`
  MODIFY `IdCategoriaProfissional` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cultura`
--
ALTER TABLE `cultura`
  MODIFY `IdCultura` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `medicao`
--
ALTER TABLE `medicao`
  MODIFY `IdVariávelMedida` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `medicaoluminosidade`
--
ALTER TABLE `medicaoluminosidade`
  MODIFY `IdMedição` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `medicaotemperatura`
--
ALTER TABLE `medicaotemperatura`
  MODIFY `IdMedição` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tipocultura`
--
ALTER TABLE `tipocultura`
  MODIFY `IdTipoCultura` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `utilizador`
--
ALTER TABLE `utilizador`
  MODIFY `IdUtilizador` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `variavel`
--
ALTER TABLE `variavel`
  MODIFY `IdVariável` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `variavelmedida`
--
ALTER TABLE `variavelmedida`
  MODIFY `IdVariávelMedida` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `cultura`
--
ALTER TABLE `cultura`
  ADD CONSTRAINT `cultura_ibfk_1` FOREIGN KEY (`IdTipoCultura`) REFERENCES `tipocultura` (`IdTipoCultura`),
  ADD CONSTRAINT `cultura_ibfk_2` FOREIGN KEY (`IdUtilizador`) REFERENCES `utilizador` (`IdUtilizador`);

--
-- Limitadores para a tabela `medicao`
--
ALTER TABLE `medicao`
  ADD CONSTRAINT `medicao_ibfk_1` FOREIGN KEY (`IdVariávelMedida`) REFERENCES `variavelmedida` (`IdVariávelMedida`);

--
-- Limitadores para a tabela `utilizador`
--
ALTER TABLE `utilizador`
  ADD CONSTRAINT `utilizador_ibfk_1` FOREIGN KEY (`CategoriaProfissional`) REFERENCES `categoriaprofissional` (`IdCategoriaProfissional`);

--
-- Limitadores para a tabela `variavel`
--
ALTER TABLE `variavel`
  ADD CONSTRAINT `variavel_ibfk_1` FOREIGN KEY (`IdUtilizador`) REFERENCES `utilizador` (`IdUtilizador`);

--
-- Limitadores para a tabela `variavelmedida`
--
ALTER TABLE `variavelmedida`
  ADD CONSTRAINT `variavelmedida_ibfk_1` FOREIGN KEY (`IdCultura`) REFERENCES `cultura` (`IdCultura`),
  ADD CONSTRAINT `variavelmedida_ibfk_2` FOREIGN KEY (`IdVariável`) REFERENCES `variavel` (`IdVariável`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
