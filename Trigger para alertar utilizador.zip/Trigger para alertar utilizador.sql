CREATE TRIGGER `alertarUtilizador` AFTER INSERT ON `medicao`
 FOR EACH ROW BEGIN

	SELECT LimiteInferior INTO @lI FROM variavel_medida WHERE new.IdCultura=variavel_medida.IdCultura AND new.IdVariavel=variavel_medida.IdVariavel;
    
    SELECT LimiteSuperior INTO @lS FROM variavel_medida WHERE new.IdCultura=variavel_medida.IdCultura AND new.IdVariavel=variavel_medida.IdVariavel;
    
    SELECT LimiteRegularidadeAlertasInferior INTO @lRAI FROM variavel_medida WHERE new.IdCultura=variavel_medida.IdCultura AND new.IdVariavel=variavel_medida.IdVariavel;
    
    SELECT LimiteRegularidadeAlertasSuperior INTO @lRAS FROM variavel_medida WHERE new.IdCultura=variavel_medida.IdCultura AND new.IdVariavel=variavel_medida.IdVariavel;
    
    SELECT NomeVariavel INTO @nomeV FROM variavel WHERE  new.IdVariavel=variavel.IdVariavel;
    
    IF ((new.ValorMedicao < @lRAI) AND (new.ValorMedicao > @lI + (@lI * 0.05))) THEN INSERT INTO alerta_cultura(DataHoraAlerta, NomeVariavelAlerta, LimiteSuperiorAlerta, LimiteInferiorAlerta, ValorMedicaoAlerta, Descricao) VALUES (now(), @nomeV, @lS, @lI, new.ValorMedicao, "ATENÇÃO: A CHEGAR AO LIMITE INFERIOR"); END IF;
    
    IF ((new.ValorMedicao <= @lI + (@lI * 0.05))) THEN INSERT INTO alerta_cultura(DataHoraAlerta, NomeVariavelAlerta, LimiteSuperiorAlerta, LimiteInferiorAlerta, ValorMedicaoAlerta, Descricao) VALUES (now(), @nomeV, @lS, @lI, new.ValorMedicao, "ATENÇÃO: EM ESTADO CRÍTICO, ATINGIU O LIMITE INFERIOR"); END IF;
    
    IF ((new.ValorMedicao <= (@lS * 0.95)) AND (new.ValorMedicao > @lRAS)) THEN INSERT INTO alerta_cultura(DataHoraAlerta, NomeVariavelAlerta, LimiteSuperiorAlerta, LimiteInferiorAlerta, ValorMedicaoAlerta, Descricao) VALUES (now(), @nomeV, @lS, @lI, new.ValorMedicao, "ATENÇÃO: A CHEGAR AO LIMITE SUPERIOR"); END IF;
    
    IF ((new.ValorMedicao > @lS * 0.95)) THEN INSERT INTO alerta_cultura(DataHoraAlerta, NomeVariavelAlerta, LimiteSuperiorAlerta, LimiteInferiorAlerta, ValorMedicaoAlerta, Descricao) VALUES (now(), @nomeV, @lS, @lI, new.ValorMedicao, "ATENÇÃO: EM ESTADO CRÍTICO, ATINGIU O LIMITE SUPERIOR"); END IF;
    
    
END