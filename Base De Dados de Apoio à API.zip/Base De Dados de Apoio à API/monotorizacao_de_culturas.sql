-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 13-Maio-2019 às 17:56
-- Versão do servidor: 10.1.37-MariaDB
-- versão do PHP: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `monotorizacao_de_culturas`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `alterarCulturaDescricao` (IN `descC` VARCHAR(100), IN `idC` INT(11))  BEGIN

	UPDATE cultura SET DescricaoCultura=descC WHERE IdCultura=idC;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `alterarCulturaNome` (IN `nomeC` VARCHAR(100), IN `idC` INT(11))  BEGIN

	DELETE FROM variavel_medida WHERE IdCultura=idC;

	UPDATE cultura SET NomeCultura=nomeC WHERE IdCultura=idC;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `alterarCulturaUtilizador` (IN `nomeU` VARCHAR(100), IN `idC` INT(11))  BEGIN

	SELECT IdUtilizador INTO @idU FROM utilizador WHERE NomeUtilizador=nomeU;

	UPDATE cultura SET IdUtilizador=@idU WHERE IdCultura=idC;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `alterarUtilizadorEmail` (IN `mailU` VARCHAR(100), IN `idU` VARCHAR(100))  BEGIN

	UPDATE utilizador SET Email=mailU WHERE IdUtilizador=idU;
    
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `alterarUtilizadorNome` (IN `nomeU` VARCHAR(100), IN `idU` INT(11))  BEGIN

	DELETE FROM cultura WHERE IdUtilizador=idU;
    
    SELECT NomeUtilizador INTO @nomeUA FROM utilizador WHERE IdUtilizador=idU;
    
    SET @query1 = CONCAT('RENAME USER "',@nomeUA,'"@"localhost" TO "',nomeU,'"@"localhost"');

    PREPARE stmt FROM @query1;
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;

	UPDATE utilizador SET NomeUtilizador=nomeU WHERE IdUtilizador=idU;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `alterarUtilizadorPass` (IN `pass` VARCHAR(50), IN `idU` INT(11))  BEGIN

	UPDATE utilizador SET Passwor=pass WHERE IdUtilizador=idU;
    
    SELECT NomeUtilizador INTO @nomeU FROM utilizador WHERE IdUtilizador=idU;
    
    SET @query1 := CONCAT('SET PASSWORD FOR "', @nomeU, '"@"localhost" = PASSWORD("',pass,'") ');
    
    PREPARE stmt FROM @query1;
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
    
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `alterarVariavelMedidaAlertaLimiteInferior` (IN `regulLimiteI` DECIMAL, IN `idVM` INT(11))  BEGIN

	UPDATE variavel_medida SET LimiteRegularidadeAlertasInferior=regulLimiteI WHERE IdVariavelMedida=idVM;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `alterarVariavelMedidaAlertaLimiteSuperior` (IN `regulLimiteS` DECIMAL, IN `idVM` INT(11))  BEGIN

	UPDATE variavel_medida SET LimiteRegularidadeAlertasSuperior=regulLimiteS WHERE IdVariavelMedida=idVM;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `alterarVariavelMedidaCultura` (IN `nomeC` VARCHAR(100), IN `idVM` INT)  BEGIN

	SELECT IdCultura INTO @idC FROM cultura WHERE NomeCultura=nomeC;

	DELETE FROM medicao WHERE IdCultura=@idC;

	UPDATE variavel_medida SET IdCultura=@idC WHERE IdVariavelMedida=idVM;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `alterarVariavelMedidaLimiteInferior` (IN `limiteI` DECIMAL, IN `idVM` INT(11))  BEGIN

	UPDATE variavel_medida SET LimiteInferior=limiteI WHERE IdVariavelMedida=idVM;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `alterarVariavelMedidaLimiteSuperior` (IN `limiteS` DECIMAL, IN `idVM` INT(11))  BEGIN

	UPDATE variavel_medida SET LimiteSuperior=limiteS WHERE IdVariavelMedida=idVM;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `alterarVariavelMedidaVariavel` (IN `nomeV` VARCHAR(100), IN `idVM` INT(11))  BEGIN

	SELECT IdVariavel INTO @idV FROM variavel WHERE NomeVariavel=nomeV;
    
    SELECT IdCultura INTO @idC from variavel_medida WHERE IdVariavel=@idV AND IdVariavelMedida=idVM;
    
    DELETE FROM medicao WHERE IdVariavel=@idV AND IdCultura=@idC;

	UPDATE variavel_medida SET IdVariavel=@idV WHERE IdVariavelMedida=idVM;
    
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `alterarVariavelNome` (IN `nomeV` VARCHAR(100), IN `idV` INT(11))  BEGIN

	UPDATE variavel SET NomeVariavel=nomeV WHERE IdVariavel=idV;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `apagarCultura` (IN `idC` INT(11))  BEGIN
    
    DELETE FROM cultura WHERE IdCultura=idC;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `apagarUtilizador` (IN `idU` INT(11))  BEGIN

	SELECT NomeUtilizador INTO @nomeU FROM utilizador WHERE IdUtilizador=idU;

	DELETE FROM utilizador WHERE IdUtilizador=idU;
    
    SET @query1 := CONCAT('DROP USER "',@nomeU, '"@"localhost" ');
    
     PREPARE stmt FROM @query1;
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
   
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `apagarVariavel` (IN `idV` INT(11))  BEGIN

	DELETE FROM variavel WHERE IdVariavel=idV;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `consultarCulturas` ()  BEGIN

	SELECT IdCultura, NomeCultura, DescricaoCultura, NomeUtilizador FROM cultura, utilizador WHERE cultura.IdUtilizador=utilizador.IdUtilizador;
    
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `consultarMedicoes` ()  BEGIN

	SELECT IdMedicao, DataHoraMedicao, ValorMedicao, NomeCultura, NomeVariavel FROM variavel, medicao, cultura WHERE cultura.IdCultura = medicao.IdCultura AND medicao.IdVariavel = variavel.IdVariavel;
    
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `consultarUtilizadores` ()  BEGIN

	SELECT IdUtilizador, Email, NomeUtilizador, Passwor FROM utilizador;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `consultarVariaveis` ()  BEGIN

	SELECT * FROM variavel;
    
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `consultarVariaveisInvestigador` ()  BEGIN

	SELECT IdVariavel, NomeVariavel FROM variavel;
    
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `consultarVariaveisMedidas` ()  BEGIN

	SELECT IdVariavelMedida, LimiteInferior, LimiteSuperior, LimiteRegularidadeAlertasInferior, LimiteRegularidadeAlertasSuperior, NomeCultura, NomeVariavel FROM variavel, variavel_medida, cultura WHERE cultura.IdCultura = variavel_medida.IdCultura AND variavel_medida.IdVariavel = variavel.IdVariavel;
    
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `filtrarAlertasCultura` ()  BEGIN

	SET @nome := USER();
    SET @nomeutilizador := SUBSTRING_INDEX(@nome, '@', 1);
    
    SELECT IdUtilizador INTO @idU FROM utilizador WHERE NomeUtilizador=@nomeutilizador;
    
    SELECT DataHoraAlerta,NomeVariavelAlerta, LimiteSuperiorAlerta, LimiteInferiorAlerta, ValorMedicaoAlerta, Descricao FROM alerta_cultura, variavel_medida, variavel, cultura WHERE alerta_cultura.NomeVariavelAlerta=variavel.NomeVariavel AND variavel_medida.IdVariavel=variavel.IdVariavel AND variavel_medida.IdCultura=cultura.IdCultura AND cultura.IdUtilizador=@idU;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `filtrarCulturaTudo` ()  BEGIN

	SET @nome := USER();
    SET @nomeUtilizador := SUBSTRING_INDEX(@nome, '@', 1);

	SELECT IdUtilizador INTO @idU FROM utilizador WHERE NomeUtilizador=@nomeUtilizador;

        SELECT IdCultura, NomeCultura, DescricaoCultura FROM cultura WHERE cultura.IdUtilizador=@idU;
        
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `filtrarMedicaoTudo` ()  BEGIN

	SET @nome := USER();
    SET @nomeutilizador := SUBSTRING_INDEX(@nome,'@',1);

	SELECT IDUTilizador INTO @idU FROM utilizador WHERE NomeUtilizador=@nomeutilizador;

        SELECT NomeCultura, NomeVariavel, DataHoraMedicao, ValorMedicao, LimiteInferior, LimiteSuperior FROM medicao, cultura, variavel_medida, variavel WHERE variavel_medida.IDVariavel=variavel.IDVariavel AND medicao.IDVariavel=variavel.IDVariavel AND medicao.IDCultura=cultura.IDCultura AND variavel_medida.IDCultura=cultura.IDCultura AND cultura.IdUtilizador=@idU;
        
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `filtrarVariaveisMedidasTudo` ()  BEGIN

	SET @nome := USER();
    SET @nomeutilizador := SUBSTRING_INDEX(@nome,'@',1);

	SELECT IdUTilizador INTO @idU FROM utilizador WHERE NomeUtilizador=@nomeutilizador;

        SELECT IdVariavelMedida,LimiteInferior, LimiteSuperior, LimiteRegularidadeAlertasInferior, LimiteRegularidadeAlertasSuperior, NomeCultura, NomeVariavel FROM variavel_medida, cultura, variavel WHERE cultura.IdCultura=variavel_medida.IdCultura AND variavel.IdVariavel=variavel_medida.IdVariavel AND cultura.IdUtilizador=@idU;
        
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `inserirAdmin` (IN `mailU` VARCHAR(100), IN `nomeU` VARCHAR(100), IN `pass` VARCHAR(50))  BEGIN

    INSERT INTO utilizador(Email, NomeUtilizador, TipoUtilizador, Passwor) VALUES (mailU, nomeU, 1, pass);
    
    SET @query1 = CONCAT('CREATE USER "',nomeU,'"@"localhost" IDENTIFIED BY "',pass,'" ');

    PREPARE stmt FROM @query1;
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;

   SET @priv := CONCAT('GRANT ALL PRIVILEGES ON  *.* TO "',nomeU, '"@"localhost"');

    PREPARE stmt FROM @priv;
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
    
    FLUSH PRIVILEGES;
    
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `inserirCultura` (IN `nomeC` VARCHAR(100), IN `descrC` TEXT)  BEGIN

    SET @nome := USER();
    SET @nomeutilizador := SUBSTRING_INDEX(@nome,'@',1);

    SELECT IDUtilizador INTO @idU FROM utilizador WHERE NomeUtilizador=@nomeutilizador;

    INSERT INTO cultura(NomeCultura, DescricaoCultura, TipoCultura, IDUtilizador) VALUES (nomeC, descrC, 1, @idU);

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `inserirInvestigador` (IN `mailU` VARCHAR(100), IN `nomeU` VARCHAR(100), IN `pass` VARCHAR(50))  BEGIN
	   
    INSERT INTO utilizador(Email, NomeUtilizador, TipoUtilizador, Passwor) VALUES (mailU, nomeU, 2, pass);
    
    SET @query1 = CONCAT('CREATE USER "',nomeU,'"@"localhost" IDENTIFIED BY "',pass,'" ');

    PREPARE stmt FROM @query1;
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
    
    SET @query3 := CONCAT('GRANT EXECUTE ON PROCEDURE monotorizacao_de_culturas.filtrarMedicaoTudo TO "', nomeU, '"@"localhost"');

    PREPARE stmt FROM @query3;
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
    
    FLUSH PRIVILEGES;
    
     SET @query5 := CONCAT('GRANT EXECUTE ON PROCEDURE monotorizacao_de_culturas.filtrarCulturaTudo TO "', nomeU, '"@"localhost"');

    PREPARE stmt FROM @query5;
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;

	FLUSH PRIVILEGES;
    
    SET @query6 := CONCAT('GRANT EXECUTE ON PROCEDURE monotorizacao_de_culturas.inserirCultura TO "', nomeU, '"@"localhost"');

    PREPARE stmt FROM @query6;
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
    
    FLUSH PRIVILEGES;
    
    SET @query7 := CONCAT('GRANT EXECUTE ON PROCEDURE monotorizacao_de_culturas.apagarCultura TO "', nomeU, '"@"localhost"');

    PREPARE stmt FROM @query7;
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
    
    FLUSH PRIVILEGES;
    
    SET @query8 := CONCAT('GRANT EXECUTE ON PROCEDURE monotorizacao_de_culturas.alterarCulturaNome TO "', nomeU, '"@"localhost"');

    PREPARE stmt FROM @query8;
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
    
    FLUSH PRIVILEGES;
    
    SET @query9 := CONCAT('GRANT EXECUTE ON PROCEDURE monotorizacao_de_culturas.alterarCulturaDescricao TO "', nomeU, '"@"localhost"');

    PREPARE stmt FROM @query9;
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
    
    FLUSH PRIVILEGES;
    
    SET @query10 := CONCAT('GRANT EXECUTE ON PROCEDURE monotorizacao_de_culturas.alterarCulturaUtilizador TO "',nomeU, '"@"localhost"');

    PREPARE stmt FROM @query10;
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
    
    FLUSH PRIVILEGES;
    
    SET @query11 := CONCAT('GRANT EXECUTE ON PROCEDURE monotorizacao_de_culturas.inserirMedicao TO "', nomeU, '"@"localhost"');

    PREPARE stmt FROM @query11;
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
    
    FLUSH PRIVILEGES;
    
    SET @query12 := CONCAT('GRANT EXECUTE ON PROCEDURE monotorizacao_de_culturas.inserirVariavelMedida TO "', nomeU, '"@"localhost"');

    PREPARE stmt FROM @query12;
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
    
    FLUSH PRIVILEGES;
    
    SET @query13 := CONCAT('GRANT EXECUTE ON PROCEDURE monotorizacao_de_culturas.alterarVariavelMedidaLimiteSuperior TO "', nomeU, '"@"localhost"');

    PREPARE stmt FROM @query13;
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
    
    FLUSH PRIVILEGES;
    
    SET @query14 := CONCAT('GRANT EXECUTE ON PROCEDURE monotorizacao_de_culturas.alterarVariavelMedidaLimiteInferior TO "', nomeU, '"@"localhost"');

    PREPARE stmt FROM @query14;
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
    
    FLUSH PRIVILEGES;
    
    SET @query15 := CONCAT('GRANT EXECUTE ON PROCEDURE monotorizacao_de_culturas.alterarVariavelMedidaAlertaLimiteInferior TO "', nomeU, '"@"localhost"');

    PREPARE stmt FROM @query15;
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
    
    FLUSH PRIVILEGES;
    
    SET @query16 := CONCAT('GRANT EXECUTE ON PROCEDURE monotorizacao_de_culturas.alterarVariavelMedidaAlertaLimiteSuperior TO "', nomeU, '"@"localhost"');

    PREPARE stmt FROM @query16;
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
    
    FLUSH PRIVILEGES;
    
    SET @query17 := CONCAT('GRANT EXECUTE ON PROCEDURE monotorizacao_de_culturas.alterarVariavelMedidaVariavel TO "', nomeU, '"@"localhost"');

    PREPARE stmt FROM @query17;
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
    
    FLUSH PRIVILEGES;
    
    SET @query18 := CONCAT('GRANT EXECUTE ON PROCEDURE monotorizacao_de_culturas.alterarVariavelMedidaCultura TO "', nomeU, '"@"localhost"');

    PREPARE stmt FROM @query18;
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
    
    FLUSH PRIVILEGES;
    
    SET @query19 := CONCAT('GRANT EXECUTE ON PROCEDURE monotorizacao_de_culturas.consultarVariaveisInvestigador TO "', nomeU, '"@"localhost"');

	PREPARE stmt FROM @query19;
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
    
    FLUSH PRIVILEGES;
    
    SET @query20 := CONCAT('GRANT EXECUTE ON PROCEDURE monotorizacao_de_culturas.filtrarVariaveisMedidasTudo TO "', nomeU, '"@"localhost"');

	PREPARE stmt FROM @query20;
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
    
    FLUSH PRIVILEGES;
    
     SET @query21 := CONCAT('GRANT EXECUTE ON PROCEDURE monotorizacao_de_culturas.filtrarAlertasCultura TO "', nomeU, '"@"localhost"');

	PREPARE stmt FROM @query21;
    EXECUTE stmt; 
    DEALLOCATE PREPARE stmt;
    
    FLUSH PRIVILEGES;
    
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `inserirMedicao` (IN `valorM` DECIMAL, IN `nomeC` VARCHAR(100), IN `nomeV` VARCHAR(100))  BEGIN

	SET @nome := USER();
    SET @nomeutilizador := SUBSTRING_INDEX(@nome, '@', 1);
    
    SELECT IdUtilizador INTO @idU FROM utilizador WHERE NomeUtilizador=@nomeutilizador;

	SELECT IdCultura INTO @idC FROM cultura WHERE IdUtilizador=@idU AND NomeCultura=nomeC;
    
    SELECT IdVariavel INTO @idV FROM variavel WHERE variavel.NomeVariavel=nomeV;

	INSERT INTO medicao(ValorMedicao, IdCultura, IdVariavel) VALUES (valorM, @idC, @idV);

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `inserirVariavel` (IN `nomeV` VARCHAR(100))  BEGIN

	INSERT INTO variavel(NomeVariavel) VALUES (nomeV);

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `inserirVariavelMedida` (IN `limiteI` DECIMAL, IN `limiteS` DECIMAL, IN `nomeV` VARCHAR(100), IN `nomeC` VARCHAR(100), IN `regulLimiteI` DECIMAL, IN `regulLimiteS` DECIMAL)  BEGIN

	SET @nome := USER();
    SET @nomeutilizador := SUBSTRING_INDEX(@nome, '@', 1);
    
    SELECT IdUtilizador INTO @idU FROM utilizador WHERE NomeUtilizador=@nomeutilizador;
    
    SELECT IdCultura INTO @idC FROM cultura WHERE cultura.IdUtilizador=@idU AND NomeCultura=nomeC;
    
    SELECT IdVariavel INTO @idV FROM variavel WHERE NomeVariavel=nomeV;
    
    INSERT INTO variavel_medida(LimiteInferior, LimiteSuperior, LimiteRegularidadeAlertasInferior, LimiteRegularidadeAlertasSuperior, IdCultura, IdVariavel) VALUES (limiteI, limiteS, regulLimiteI, regulLimiteS, @idC, @idV);

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `obterPassword` (IN `nomeU` VARCHAR(100))  BEGIN

	SELECT Passwor FROM utilizador WHERE NomeUtilizador=nomeU;
    
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `obterTipoUtilizador` (IN `nomeU` VARCHAR(100))  BEGIN

	SELECT TipoUtilizador INTO @idT FROM utilizador WHERE NomeUtilizador=nomeU;

	SELECT TipoUtilizador FROM tipo_utilizador WHERE IDTipoUtilizador=@idT;

END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `alertas_globais`
--

CREATE TABLE `alertas_globais` (
  `IdAlerta` int(11) NOT NULL,
  `DataHoraAlerta` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `NomeVariavel` enum('Temperatura','Luminosidade') NOT NULL,
  `LimiteSuperior` decimal(8,2) NOT NULL,
  `LimiteInferior` decimal(8,2) NOT NULL,
  `ValorMedicao` decimal(8,2) NOT NULL,
  `Descricao` text NOT NULL,
  `IdRegularidadeAlertasGlobais` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `alerta_cultura`
--

CREATE TABLE `alerta_cultura` (
  `IdAlerta` int(11) NOT NULL,
  `DataHoraAlerta` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `NomeVariavel` varchar(100) NOT NULL,
  `LimiteSuperior` decimal(8,2) NOT NULL,
  `LimiteInferior` decimal(8,2) NOT NULL,
  `ValorMedicao` decimal(8,2) NOT NULL,
  `Descricao` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `alerta_cultura`
--

INSERT INTO `alerta_cultura` (`IdAlerta`, `DataHoraAlerta`, `NomeVariavel`, `LimiteSuperior`, `LimiteInferior`, `ValorMedicao`, `Descricao`) VALUES
(0, '2019-05-09 19:15:10', 'var1', '20.00', '10.00', '19.00', 'ATENÇÃO: A CHEGAR AO LIMITE SUPERIOR');

-- --------------------------------------------------------

--
-- Estrutura da tabela `cultura`
--

CREATE TABLE `cultura` (
  `IdCultura` int(11) NOT NULL,
  `NomeCultura` varchar(100) NOT NULL,
  `DescricaoCultura` text,
  `TipoCultura` int(11) NOT NULL,
  `IdUtilizador` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `cultura`
--

INSERT INTO `cultura` (`IdCultura`, `NomeCultura`, `DescricaoCultura`, `TipoCultura`, `IdUtilizador`) VALUES
(1, 'cul1', 'sadsa', 1, 9),
(2, 'cul2', 'asdsad', 1, 9),
(3, 'cul3', 'asdsad', 1, 10),
(4, 'cultura1', 'dsfdsfd', 1, 12),
(5, 'cultura2', 'cultura2', 1, 12),
(7, 'cultura3', 'dasassa', 1, 12),
(8, 'cultura8', 'lkfldsf', 1, 12),
(9, 'cul9', 'dsdsgs', 1, 12),
(10, 'cul10', 'sadsada', 1, 12),
(11, 'cultura7', 'asdasd', 1, 12),
(15, 'cultura11', 'sadasdasd', 1, 12);

-- --------------------------------------------------------

--
-- Estrutura da tabela `medicao`
--

CREATE TABLE `medicao` (
  `IdMedicao` int(11) NOT NULL,
  `DataHoraMedicao` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ValorMedicao` decimal(8,2) NOT NULL,
  `IdCultura` int(11) NOT NULL,
  `IdVariavel` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `medicao`
--

INSERT INTO `medicao` (`IdMedicao`, `DataHoraMedicao`, `ValorMedicao`, `IdCultura`, `IdVariavel`) VALUES
(20, '2019-05-11 18:09:39', '23.00', 1, 11),
(21, '2019-05-11 18:09:53', '67.00', 3, 12),
(23, '2019-05-11 18:12:39', '111.00', 5, 15),
(25, '2019-05-11 18:20:00', '90.00', 4, 14);

-- --------------------------------------------------------

--
-- Estrutura da tabela `medicao_temperatura_luminosidade`
--

CREATE TABLE `medicao_temperatura_luminosidade` (
  `IdMedicaoTemperaturaLuminosidade` int(11) NOT NULL,
  `DataHoraMedicao` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ValorMedicaoTemperatura` decimal(8,2) NOT NULL,
  `ValorMedicaoLuminosidade` decimal(8,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `regularidade_alertas_globais`
--

CREATE TABLE `regularidade_alertas_globais` (
  `IdRegularidadeAlertasGlobais` int(11) NOT NULL,
  `LimiteSuperior` decimal(8,2) NOT NULL,
  `LimiteInferior` decimal(8,2) NOT NULL,
  `IdUtilizador` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `sistema`
--

CREATE TABLE `sistema` (
  `LimiteSuperiorTemperatura` decimal(8,2) NOT NULL,
  `LimiteInferiorTemperatura` decimal(8,2) NOT NULL,
  `LimiteSuperiorLuminosidade` decimal(8,2) NOT NULL,
  `LimiteInferiorLuminosidade` decimal(8,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `sistema`
--

INSERT INTO `sistema` (`LimiteSuperiorTemperatura`, `LimiteInferiorTemperatura`, `LimiteSuperiorLuminosidade`, `LimiteInferiorLuminosidade`) VALUES
('20.00', '2.00', '2000.00', '500.00'),
('10.00', '-5.00', '1000.00', '250.00'),
('30.00', '1.00', '3000.00', '1000.00'),
('20.00', '2.00', '2000.00', '500.00'),
('10.00', '-5.00', '1000.00', '250.00'),
('30.00', '1.00', '3000.00', '1000.00');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tipo_cultura`
--

CREATE TABLE `tipo_cultura` (
  `IdTipoCultura` int(11) NOT NULL,
  `NomeCultura` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `tipo_cultura`
--

INSERT INTO `tipo_cultura` (`IdTipoCultura`, `NomeCultura`) VALUES
(1, 'tipo1');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tipo_utilizador`
--

CREATE TABLE `tipo_utilizador` (
  `IdTipoUtilizador` int(11) NOT NULL,
  `TipoUtilizador` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `tipo_utilizador`
--

INSERT INTO `tipo_utilizador` (`IdTipoUtilizador`, `TipoUtilizador`) VALUES
(1, 'Administrador'),
(2, 'Investigador');

-- --------------------------------------------------------

--
-- Estrutura da tabela `utilizador`
--

CREATE TABLE `utilizador` (
  `IdUtilizador` int(11) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `NomeUtilizador` varchar(100) NOT NULL,
  `TipoUtilizador` int(11) NOT NULL,
  `Passwor` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `utilizador`
--

INSERT INTO `utilizador` (`IdUtilizador`, `Email`, `NomeUtilizador`, `TipoUtilizador`, `Passwor`) VALUES
(9, 'a@gmail.com', 'a', 1, 'a'),
(10, 'a2@gamil.com', 'a2', 1, 'a2'),
(12, 'i@gmail.com', 'i', 2, 'i'),
(13, 'i2@gmail.com', 'i2', 2, 'i2'),
(14, 'i3@gmail.com', 'i3', 2, 'i3'),
(16, 'a3@gmail.com', 'a3', 2, 'a3');

-- --------------------------------------------------------

--
-- Estrutura da tabela `variavel`
--

CREATE TABLE `variavel` (
  `IdVariavel` int(11) NOT NULL,
  `NomeVariavel` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `variavel`
--

INSERT INTO `variavel` (`IdVariavel`, `NomeVariavel`) VALUES
(11, 'variável1'),
(12, 'variável2'),
(14, 'variável3'),
(15, 'variável4');

-- --------------------------------------------------------

--
-- Estrutura da tabela `variavel_medida`
--

CREATE TABLE `variavel_medida` (
  `IdVariavelMedida` int(11) NOT NULL,
  `LimiteInferior` decimal(8,2) NOT NULL,
  `LimiteSuperior` decimal(8,2) NOT NULL,
  `LimiteRegularidadeAlertasInferior` decimal(8,2) NOT NULL,
  `LimiteRegularidadeAlertasSuperior` decimal(8,2) NOT NULL,
  `IdCultura` int(11) NOT NULL,
  `IdVariavel` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `alertas_globais`
--
ALTER TABLE `alertas_globais`
  ADD PRIMARY KEY (`IdAlerta`),
  ADD KEY `alertas_globais_ibfk_1` (`IdRegularidadeAlertasGlobais`);

--
-- Indexes for table `alerta_cultura`
--
ALTER TABLE `alerta_cultura`
  ADD PRIMARY KEY (`IdAlerta`);

--
-- Indexes for table `cultura`
--
ALTER TABLE `cultura`
  ADD PRIMARY KEY (`IdCultura`),
  ADD KEY `cultura_ibfk_2` (`TipoCultura`),
  ADD KEY `cultura_ibfk_3` (`IdUtilizador`);

--
-- Indexes for table `medicao`
--
ALTER TABLE `medicao`
  ADD PRIMARY KEY (`IdMedicao`),
  ADD KEY `medicao_ibfk_1` (`IdCultura`),
  ADD KEY `medicao_ibfk_2` (`IdVariavel`);

--
-- Indexes for table `medicao_temperatura_luminosidade`
--
ALTER TABLE `medicao_temperatura_luminosidade`
  ADD PRIMARY KEY (`IdMedicaoTemperaturaLuminosidade`);

--
-- Indexes for table `regularidade_alertas_globais`
--
ALTER TABLE `regularidade_alertas_globais`
  ADD PRIMARY KEY (`IdRegularidadeAlertasGlobais`),
  ADD KEY `regularidade_alertas_globais_ibfk_1` (`IdUtilizador`);

--
-- Indexes for table `tipo_cultura`
--
ALTER TABLE `tipo_cultura`
  ADD PRIMARY KEY (`IdTipoCultura`),
  ADD UNIQUE KEY `NomeCultura` (`NomeCultura`);

--
-- Indexes for table `tipo_utilizador`
--
ALTER TABLE `tipo_utilizador`
  ADD PRIMARY KEY (`IdTipoUtilizador`),
  ADD UNIQUE KEY `NomeCategoriaProfissional` (`TipoUtilizador`);

--
-- Indexes for table `utilizador`
--
ALTER TABLE `utilizador`
  ADD PRIMARY KEY (`IdUtilizador`),
  ADD UNIQUE KEY `Email` (`Email`),
  ADD UNIQUE KEY `NomeUtilizador_UNIQUE` (`NomeUtilizador`),
  ADD KEY `utilizador_ibfk_1` (`TipoUtilizador`);

--
-- Indexes for table `variavel`
--
ALTER TABLE `variavel`
  ADD PRIMARY KEY (`IdVariavel`);

--
-- Indexes for table `variavel_medida`
--
ALTER TABLE `variavel_medida`
  ADD PRIMARY KEY (`IdVariavelMedida`),
  ADD KEY `variavel_medida_ibfk_1` (`IdCultura`),
  ADD KEY `variavel_medida_ibfk_2` (`IdVariavel`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `alertas_globais`
--
ALTER TABLE `alertas_globais`
  MODIFY `IdAlerta` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `alerta_cultura`
--
ALTER TABLE `alerta_cultura`
  MODIFY `IdAlerta` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cultura`
--
ALTER TABLE `cultura`
  MODIFY `IdCultura` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `medicao`
--
ALTER TABLE `medicao`
  MODIFY `IdMedicao` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `medicao_temperatura_luminosidade`
--
ALTER TABLE `medicao_temperatura_luminosidade`
  MODIFY `IdMedicaoTemperaturaLuminosidade` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `regularidade_alertas_globais`
--
ALTER TABLE `regularidade_alertas_globais`
  MODIFY `IdRegularidadeAlertasGlobais` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tipo_cultura`
--
ALTER TABLE `tipo_cultura`
  MODIFY `IdTipoCultura` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tipo_utilizador`
--
ALTER TABLE `tipo_utilizador`
  MODIFY `IdTipoUtilizador` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `utilizador`
--
ALTER TABLE `utilizador`
  MODIFY `IdUtilizador` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `variavel`
--
ALTER TABLE `variavel`
  MODIFY `IdVariavel` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `variavel_medida`
--
ALTER TABLE `variavel_medida`
  MODIFY `IdVariavelMedida` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `alertas_globais`
--
ALTER TABLE `alertas_globais`
  ADD CONSTRAINT `alertas_globais_ibfk_1` FOREIGN KEY (`IdRegularidadeAlertasGlobais`) REFERENCES `regularidade_alertas_globais` (`IdRegularidadeAlertasGlobais`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limitadores para a tabela `cultura`
--
ALTER TABLE `cultura`
  ADD CONSTRAINT `cultura_ibfk_2` FOREIGN KEY (`TipoCultura`) REFERENCES `tipo_cultura` (`IdTipoCultura`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cultura_ibfk_3` FOREIGN KEY (`IdUtilizador`) REFERENCES `utilizador` (`IdUtilizador`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limitadores para a tabela `medicao`
--
ALTER TABLE `medicao`
  ADD CONSTRAINT `medicao_ibfk_1` FOREIGN KEY (`IdCultura`) REFERENCES `cultura` (`IdCultura`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `medicao_ibfk_2` FOREIGN KEY (`IdVariavel`) REFERENCES `variavel` (`IdVariavel`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limitadores para a tabela `regularidade_alertas_globais`
--
ALTER TABLE `regularidade_alertas_globais`
  ADD CONSTRAINT `regularidade_alertas_globais_ibfk_1` FOREIGN KEY (`IdUtilizador`) REFERENCES `utilizador` (`IdUtilizador`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limitadores para a tabela `utilizador`
--
ALTER TABLE `utilizador`
  ADD CONSTRAINT `utilizador_ibfk_1` FOREIGN KEY (`TipoUtilizador`) REFERENCES `tipo_utilizador` (`IdTipoUtilizador`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limitadores para a tabela `variavel_medida`
--
ALTER TABLE `variavel_medida`
  ADD CONSTRAINT `variavel_medida_ibfk_1` FOREIGN KEY (`IdCultura`) REFERENCES `cultura` (`IdCultura`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `variavel_medida_ibfk_2` FOREIGN KEY (`IdVariavel`) REFERENCES `variavel` (`IdVariavel`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
